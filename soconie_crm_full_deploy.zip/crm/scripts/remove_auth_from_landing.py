"""
Remove Auth modals (Màn 3 & 3.1) and clean up Alpine.js in landing.html
"""
with open('crm/templates/landing.html', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Cut out MÀN 3 and MÀN 3.1
start_marker = "<!-- ========================================================\n         MÀN 3: CỬA SỔ TÀI KHOẢN NỔI"
end_marker = "<!-- ========================================================\n         MODAL 1: GIỚI THIỆU TÍNH NĂNG KHÁCH HÀNG 360°"

if start_marker in content and end_marker in content:
    idx_start = content.index(start_marker)
    idx_end = content.index(end_marker)
    content = content[:idx_start] + content[idx_end:]
    print("[OK] Removed Auth & Recovery Modals from template HTML!")
else:
    print("[WARN] Markers not found directly, checking variations...")

# 2. Update Customer 360 modal footer text
old_c360_footer = "Đăng nhập tài khoản để quản lý toàn bộ hồ sơ khách hàng thật."
new_c360_footer = "Khám phá và quản lý toàn bộ hồ sơ khách hàng doanh nghiệp trong Soconie CRM."
if old_c360_footer in content:
    content = content.replace(old_c360_footer, new_c360_footer)
    print("[OK] Updated Customer 360 modal footer text!")

# 3. Update search submit
old_search = """                handleSearchSubmit() {
                    if (!this.searchQuery.trim()) return;
                    this.showToast('✦ Trợ lý Soconie: Đang chuyển đến màn hình...');
                    setTimeout(() => { this.openAuth('login'); }, 400);
                },"""
new_search = """                handleSearchSubmit() {
                    if (this.searchQuery && this.searchQuery.trim()) {
                        window.location.href = '/khong-gian-phan-tich?q=' + encodeURIComponent(this.searchQuery.trim());
                    } else {
                        window.location.href = '/tong-quan';
                    }
                },"""
if old_search in content:
    content = content.replace(old_search, new_search)
    print("[OK] Updated handleSearchSubmit to direct navigation!")
else:
    # Try normalizing line endings
    content = content.replace("setTimeout(() => { this.openAuth('login'); }, 400);", "window.location.href = '/tong-quan';")
    print("[OK] Replaced openAuth in search submit!")

# 4. Clean up handleEscapeKey
old_esc = """                handleEscapeKey() {
                    if (this.showRecoveryModal) return;
                    if (this.showAuthModal) {
                        this.closeAuthModal();
                    } else if (this.showWelcome) {
                        this.dismissWelcome();
                    }
                },"""
new_esc = """                handleEscapeKey() {
                    if (this.showCustomer360Modal) {
                        this.showCustomer360Modal = false;
                    } else if (this.showPipelineModal) {
                        this.showPipelineModal = false;
                    } else if (this.showWelcome) {
                        this.dismissWelcome();
                    }
                },"""
if old_esc in content:
    content = content.replace(old_esc, new_esc)
    print("[OK] Updated handleEscapeKey!")

# 5. Clean up init
old_init_check = """                    if (this.showAuthModal) {
                        this.fetchCaptcha(this.authTab);
                    }"""
content = content.replace(old_init_check, "")

with open('crm/templates/landing.html', 'w', encoding='utf-8') as f:
    f.write(content)

print("[SUCCESS] landing.html updated cleanly!")
