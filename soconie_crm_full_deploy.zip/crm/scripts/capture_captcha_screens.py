"""
Capture Screenshots for Soconie CRM Slider Puzzle CAPTCHA & Security Flows
"""
import os
import subprocess
import shutil
import tempfile
import time

chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
artifact_dir = r"C:\Users\THC\.gemini\antigravity\brain\985b2eed-7902-4b89-b84c-58315124fe59"
temp_dir = tempfile.gettempdir()

targets = [
    ("shot_captcha_dev_test_light.png", "http://localhost:5000/dev/captcha-test?theme=light", 1440, 1100),
    ("shot_captcha_dev_test_dark.png", "http://localhost:5000/dev/captcha-test?theme=dark", 1440, 1100),
    ("shot_man3_captcha_modal_light.png", "http://localhost:5000/?screen=auth&theme=light&tab=register", 1440, 950),
    ("shot_man3_captcha_modal_dark.png", "http://localhost:5000/?screen=auth&theme=dark&tab=register", 1440, 950),
    ("shot_man3_recovery_codes_light.png", "http://localhost:5000/?screen=recovery&theme=light", 1440, 950),
    ("shot_man3_recovery_codes_dark.png", "http://localhost:5000/?screen=recovery&theme=dark", 1440, 950),
]

for filename, url, w, h in targets:
    tmp_out = os.path.join(temp_dir, "tmp_" + filename)
    if os.path.exists(tmp_out):
        try:
            os.remove(tmp_out)
        except:
            pass

    cmd = [
        chrome_path,
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        f"--window-size={w},{h}",
        "--hide-scrollbars",
        "--virtual-time-budget=3000",
        f"--screenshot={tmp_out}",
        url
    ]
    try:
        subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        dst = os.path.join(artifact_dir, filename)
        if os.path.exists(tmp_out):
            shutil.copyfile(tmp_out, dst)
            sz = os.path.getsize(dst)
            print(f"Captured {filename}: {sz} bytes ({w}x{h})")
        else:
            print(f"Failed to create {filename}")
    except Exception as e:
        print(f"Error capturing {filename}:", e)
