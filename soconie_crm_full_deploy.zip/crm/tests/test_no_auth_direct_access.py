"""
Verification script for complete removal of Login, Register, and Forgot Password gates.
Verifies that all users have instant, direct access as Owner Lê Minh Ngọc.
"""
import requests

BASE_URL = "http://localhost:5000"

def test_no_auth():
    # Fresh session without any cookies
    s = requests.Session()

    print("\n--- 1. Testing Auth Route Bypasses ---")
    auth_endpoints = ["/dang-nhap", "/login", "/dang-ky", "/register", "/tao-tai-khoan", "/quen-mat-khau", "/forgot-password"]
    for ep in auth_endpoints:
        r = s.get(f"{BASE_URL}{ep}", allow_redirects=False)
        assert r.status_code in [302, 301], f"Endpoint {ep} should redirect directly to dashboard, got {r.status_code}"
        assert "/tong-quan" in r.headers.get("Location", ""), f"Endpoint {ep} should redirect to /tong-quan, got {r.headers.get('Location')}"
        print(f"  [OK] {ep} redirects directly to: {r.headers.get('Location')}")

    print("\n--- 2. Testing Direct Access to Protected CRM Routes (Zero Login Gate) ---")
    protected_routes = [
        ("/tong-quan", "Tổng quan (KPIs)"),
        ("/khach-hang", "Khách hàng"),
        ("/co-hoi", "Cơ hội"),
        ("/bao-gia", "Báo giá"),
        ("/don-hang", "Đơn hàng"),
        ("/lead", "Lead tiềm năng"),
        ("/kanban", "Kanban"),
        ("/cai-dat", "Cài đặt"),
        ("/khong-gian-phan-tich", "Không gian phân tích")
    ]
    for route, label in protected_routes:
        r = s.get(f"{BASE_URL}{route}", allow_redirects=False)
        assert r.status_code == 200, f"Route {route} ({label}) failed to load directly: status {r.status_code}"
        assert "Lê Minh Ngọc" in r.text, f"Route {route} should display owner Lê Minh Ngọc in sidebar/topbar"
        print(f"  [OK] Direct access to {route} ({label}): 200 OK (Owner: Lê Minh Ngọc)")

    print("\n--- 3. Testing Landing Page (No Auth Modals, Direct Links) ---")
    r_landing = s.get(f"{BASE_URL}/")
    assert r_landing.status_code == 200
    html = r_landing.text
    # Verify auth modal is removed from template HTML
    assert "showAuthModal" not in html or 'x-show="showAuthModal"' not in html, "showAuthModal HTML should be removed!"
    assert 'x-show="showRecoveryModal"' not in html, "showRecoveryModal HTML should be removed!"
    assert "Vào CRM" in html or "Bảng Điều Khiển" in html, "Navbar should display direct CRM entrance buttons!"
    assert "Đăng nhập vào CRM" not in html, "Old login submit button should be absent!"
    print("  [OK] Landing page verified: Zero auth barriers, direct CRM buttons present!")

    print("\n================ ALL NO-AUTH DIRECT ACCESS TESTS PASSED ================\n")

if __name__ == "__main__":
    test_no_auth()
