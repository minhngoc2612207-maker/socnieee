"""
Automated Test Suite for Soconie CRM Slider Puzzle CAPTCHA & Security Auth
"""
import sys
import time
import math
import requests
import sqlite3

BASE_URL = "http://127.0.0.1:5000"

def get_verified_captcha_token(action="register"):
    res = requests.get(f"{BASE_URL}/api/captcha/challenge?action={action}")
    data = res.json()
    assert data["success"] is True
    cid = data["challenge_id"]

    conn = sqlite3.connect("crm/data/crm.db")
    c = conn.cursor()
    c.execute("SELECT correct_x FROM captcha_challenges WHERE challenge_id = ?", (cid,))
    row = c.fetchone()
    conn.close()
    assert row is not None
    actual_x = row[0]

    trail = []
    steps = 15
    duration_ms = 800
    for i in range(steps):
        t_frac = i / (steps - 1)
        cur_x = actual_x * (1 - (1 - t_frac)**2)
        cur_y = 1.8 * math.sin(t_frac * 3.14)
        trail.append({
            "x": round(cur_x, 1),
            "y": round(cur_y, 1),
            "t": int(t_frac * duration_ms)
        })

    ver_res = requests.post(f"{BASE_URL}/api/captcha/verify", json={
        "challenge_id": cid,
        "final_x": actual_x,
        "trail": trail,
        "action": action
    })
    ver_data = ver_res.json()
    assert ver_data["success"] is True, f"Failed verifying captcha for {action}: {ver_data}"
    return ver_data["captcha_token"]


def test_captcha_flow():
    print("--- 1. Testing GET /api/captcha/challenge ---")
    res = requests.get(f"{BASE_URL}/api/captcha/challenge?action=register")
    assert res.status_code == 200, f"Expected 200, got {res.status_code}: {res.text}"
    data = res.json()
    assert data["success"] is True
    cid = data["challenge_id"]
    assert "bg_image" in data
    assert "piece_image" in data
    assert "correct_x" not in data, "Security violation: correct_x exposed to client!"
    assert "original_file" not in data, "Security violation: filename exposed to client!"
    print(f"  [OK] Challenge received! ID={cid}, bg_len={len(data['bg_image'])}")

    print("\n--- 2. Testing Bot Attack (0ms instant drag) on /api/captcha/verify ---")
    bot_payload = {
        "challenge_id": cid,
        "final_x": 120,
        "trail": [{"x": 0, "y": 0, "t": 0}, {"x": 120, "y": 0, "t": 50}],
        "action": "register"
    }
    res_bot = requests.post(f"{BASE_URL}/api/captcha/verify", json=bot_payload)
    bot_data = res_bot.json()
    assert bot_data["success"] is False, "Bot drag should have failed!"
    print(f"  [OK] Bot rejected as expected: {bot_data.get('message')}")

    print("\n--- 3. Testing Real Human Drag Simulation with Correct Coordinates ---")
    reg_captcha_token = get_verified_captcha_token("register")
    print(f"  [OK] Human drag verified! Issued captcha_token = {reg_captcha_token[:12]}...")

    print("\n--- 4. Testing User Registration with CAPTCHA Token ---")
    test_phone = f"0913{int(time.time()) % 1000000:06d}"
    test_email = f"test_{int(time.time())}@example.com"
    reg_payload = {
        "full_name": "Doanh Nghiệp Minh Ngọc Test",
        "phone": test_phone,
        "email": test_email,
        "password": "Password123@",
        "confirm_password": "Password123@",
        "terms_agreed": True,
        "captcha_token": reg_captcha_token
    }
    res_reg = requests.post(f"{BASE_URL}/api/auth/register", json=reg_payload)
    reg_data = res_reg.json()
    assert reg_data["success"] is True, f"Registration failed: {reg_data}"
    assert "recovery_codes" in reg_data
    codes = reg_data["recovery_codes"]
    assert len(codes) == 8, f"Expected 8 recovery codes, got {len(codes)}"
    print(f"  [OK] User registered successfully: {test_phone} / {test_email}")
    print(f"  [OK] 8 Recovery codes generated: {codes[:3]} ... (total {len(codes)})")

    print("\n--- 5. Testing Login with New Challenge & CAPTCHA ---")
    login_captcha_token = get_verified_captcha_token("login")

    login_payload = {
        "identifier": test_phone,
        "password": "Password123@",
        "captcha_token": login_captcha_token
    }
    res_login = requests.post(f"{BASE_URL}/api/auth/login", json=login_payload)
    login_data = res_login.json()
    assert login_data["success"] is True, f"Login failed: {login_data}"
    print(f"  [OK] Login successful! Message: {login_data.get('message')}")

    print("\n--- 6. Testing Password Reset via Recovery Code ---")
    forgot_captcha_token = get_verified_captcha_token("forgot")
    first_code = codes[0]
    forgot_payload = {
        "method": "recovery_code",
        "identifier": test_email,
        "recovery_code": first_code,
        "new_password": "NewSecretPassword456@",
        "confirm_new_password": "NewSecretPassword456@",
        "captcha_token": forgot_captcha_token
    }
    res_forgot = requests.post(f"{BASE_URL}/api/auth/forgot-password", json=forgot_payload)
    forgot_data = res_forgot.json()
    assert forgot_data["success"] is True, f"Forgot password failed: {forgot_data}"
    print(f"  [OK] Password reset via recovery code succeeded! {forgot_data.get('message')}")

    # Verify that the same recovery code cannot be reused (one-time use)
    forgot_captcha_token2 = get_verified_captcha_token("forgot")
    forgot_payload["captcha_token"] = forgot_captcha_token2
    res_reuse = requests.post(f"{BASE_URL}/api/auth/forgot-password", json=forgot_payload)
    reuse_data = res_reuse.json()
    assert reuse_data["success"] is False, "Recovery code should be consumed and cannot be reused!"
    print(f"  [OK] Consumed recovery code correctly rejected on reuse: {reuse_data.get('message')}")

    print("\n--- 7. Testing Legacy SMS OTP Route Disabled ---")
    res_otp = requests.post(f"{BASE_URL}/api/auth/send-otp", json={"phone": test_phone, "action": "login"})
    assert res_otp.status_code == 403, f"Expected 403 Forbidden, got {res_otp.status_code}"
    print(f"  [OK] Legacy SMS OTP route correctly disabled (403): {res_otp.json().get('message')}")

    print("\n--- 8. Testing /dev/captcha-test Page ---")
    res_dev = requests.get(f"{BASE_URL}/dev/captcha-test")
    assert res_dev.status_code == 200
    assert "Soconie CRM" in res_dev.text
    assert "Kiểm Thử CAPTCHA Kéo Ghép Hình" in res_dev.text
    print("  [OK] Developer CAPTCHA test page rendered 200 OK!")

    print("\n================ ALL CAPTCHA & AUTH TESTS PASSED ================\n")

if __name__ == "__main__":
    test_captcha_flow()
