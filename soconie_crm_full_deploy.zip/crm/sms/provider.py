"""
SMS Provider Adapter Pattern for Soconie CRM.
Supports eSMS, SpeedSMS, Twilio, Firebase, and local DevEcho mode.
"""
import abc
import os
import json
import logging
import requests
from typing import Dict, Any

logger = logging.getLogger("soconie.sms")


class SmsProvider(abc.ABC):
    """Abstract interface for SMS providers."""

    @abc.abstractmethod
    def send_otp(self, phone_e164: str, code: str, purpose: str = "xác minh") -> Dict[str, Any]:
        """
        Sends OTP message to normalized E.164 phone number.
        Returns dict with: success (bool), provider (str), message_id (str), error (str|None)
        """
        pass


class DevEchoProvider(SmsProvider):
    """Local development SMS provider that prints OTP code to terminal."""

    def send_otp(self, phone_e164: str, code: str, purpose: str = "xác minh") -> Dict[str, Any]:
        sms_text = f"Soconie CRM: Ma xac minh cua ban la {code}. Het han sau 5 phut. Khong chia se ma cho ai."
        border = "=" * 65
        print(f"\n{border}")
        print(f"📱 [DEV_ECHO SMS] ĐÃ GỬI MÃ OTP THÀNH CÔNG (MÔ PHỎNG LOCAL)")
        print(f"   Người nhận (E.164): {phone_e164}")
        print(f"   Mã OTP 6 số:        >> {code} <<")
        print(f"   Mục đích:           {purpose}")
        print(f"   Nội dung SMS:       {sms_text}")
        print(f"{border}\n")
        return {
            "success": True,
            "provider": "dev_echo",
            "message_id": f"dev_{int(code) * 7}",
            "error": None,
            "code": code
        }


class ESmsProvider(SmsProvider):
    """eSMS.vn Provider Adapter (SMS Brandname / OTP API)."""

    def __init__(self, api_key: str, secret_key: str, brandname: str = "Soconie"):
        self.api_key = api_key
        self.secret_key = secret_key
        self.brandname = brandname
        self.endpoint = "http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_post_json"

    def send_otp(self, phone_e164: str, code: str, purpose: str = "xác minh") -> Dict[str, Any]:
        # Strip '+' for domestic Vietnamese APIs expecting '84...' or '0...'
        phone_local = phone_e164.replace("+", "")
        sms_content = f"Soconie CRM: Ma xac minh cua ban la {code}. Het han sau 5 phut. Khong chia se ma cho ai."
        
        payload = {
            "ApiKey": self.api_key,
            "SecretKey": self.secret_key,
            "Phone": phone_local,
            "Content": sms_content,
            "SmsType": "2",  # 2: Brandname CSKH / OTP
            "Brandname": self.brandname,
            "IsUnicode": "0",
            "Sandbox": "0"
        }

        try:
            res = requests.post(self.endpoint, json=payload, timeout=10)
            data = res.json()
            # eSMS: CodeResult == "100" means success
            if data.get("CodeResult") == "100":
                return {
                    "success": True,
                    "provider": "esms",
                    "message_id": data.get("SMSID", ""),
                    "error": None
                }
            error_msg = f"eSMS error {data.get('CodeResult')}: {data.get('ErrorMessage')}"
            logger.error(error_msg)
            return {"success": False, "provider": "esms", "message_id": None, "error": error_msg}
        except Exception as e:
            logger.error(f"eSMS connection error: {e}")
            return {"success": False, "provider": "esms", "message_id": None, "error": str(e)}


class SpeedSmsProvider(SmsProvider):
    """SpeedSMS.vn Provider Adapter."""

    def __init__(self, access_token: str, sender_id: str = "Soconie"):
        self.access_token = access_token
        self.sender_id = sender_id
        self.endpoint = "https://api.speedsms.vn/index.php/sms/send"

    def send_otp(self, phone_e164: str, code: str, purpose: str = "xác minh") -> Dict[str, Any]:
        phone_local = phone_e164.replace("+", "")
        sms_content = f"Soconie CRM: Ma xac minh cua ban la {code}. Het han sau 5 phut. Khong chia se ma cho ai."

        payload = {
            "to": [phone_local],
            "content": sms_content,
            "sms_type": 2,  # OTP service
            "sender": self.sender_id
        }

        try:
            res = requests.post(
                self.endpoint,
                auth=(self.access_token, "x"),
                json=payload,
                timeout=10
            )
            data = res.json()
            if data.get("status") == "success":
                return {
                    "success": True,
                    "provider": "speedsms",
                    "message_id": str(data.get("data", {}).get("tranId", "")),
                    "error": None
                }
            error_msg = f"SpeedSMS error: {data.get('message')}"
            logger.error(error_msg)
            return {"success": False, "provider": "speedsms", "message_id": None, "error": error_msg}
        except Exception as e:
            logger.error(f"SpeedSMS connection error: {e}")
            return {"success": False, "provider": "speedsms", "message_id": None, "error": str(e)}


class TwilioProvider(SmsProvider):
    """Twilio Programmable Messaging / Verify Provider Adapter."""

    def __init__(self, account_sid: str, auth_token: str, from_number: str = "Soconie"):
        self.account_sid = account_sid
        self.auth_token = auth_token
        self.from_number = from_number
        self.endpoint = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"

    def send_otp(self, phone_e164: str, code: str, purpose: str = "xác minh") -> Dict[str, Any]:
        sms_content = f"Soconie CRM: Ma xac minh cua ban la {code}. Het han sau 5 phut. Khong chia se ma cho ai."
        data = {
            "To": phone_e164,
            "From": self.from_number,
            "Body": sms_content
        }

        try:
            res = requests.post(self.endpoint, data=data, auth=(self.account_sid, self.auth_token), timeout=10)
            res_data = res.json()
            if res.status_code in (200, 201):
                return {
                    "success": True,
                    "provider": "twilio",
                    "message_id": res_data.get("sid", ""),
                    "error": None
                }
            error_msg = f"Twilio error {res_data.get('code')}: {res_data.get('message')}"
            logger.error(error_msg)
            return {"success": False, "provider": "twilio", "message_id": None, "error": error_msg}
        except Exception as e:
            logger.error(f"Twilio connection error: {e}")
            return {"success": False, "provider": "twilio", "message_id": None, "error": str(e)}


class FirebaseProvider(SmsProvider):
    """Firebase Phone Auth compatibility placeholder."""

    def __init__(self, project_id: str = ""):
        self.project_id = project_id

    def send_otp(self, phone_e164: str, code: str, purpose: str = "xác minh") -> Dict[str, Any]:
        # Firebase handles sending through client SDK reCAPTCHA verification.
        # Server verifies ID token.
        return {
            "success": True,
            "provider": "firebase",
            "message_id": "firebase_client_flow",
            "error": None
        }


def get_sms_provider() -> SmsProvider:
    """Factory creating configured SMS Provider with DevEcho fallback."""
    from crm.site_config import (
        SMS_PROVIDER,
        SMS_API_KEY,
        SMS_SECRET_KEY,
        SMS_BRANDNAME,
        OTP_DEV_ECHO
    )

    # When in dev echo mode or no keys configured, always echo safely
    if OTP_DEV_ECHO or not SMS_API_KEY:
        return DevEchoProvider()

    provider_name = SMS_PROVIDER.lower()
    if provider_name == "esms":
        return ESmsProvider(SMS_API_KEY, SMS_SECRET_KEY, SMS_BRANDNAME)
    elif provider_name == "speedsms":
        return SpeedSmsProvider(SMS_API_KEY, SMS_BRANDNAME)
    elif provider_name == "twilio":
        return TwilioProvider(SMS_API_KEY, SMS_SECRET_KEY, SMS_BRANDNAME)
    elif provider_name == "firebase":
        return FirebaseProvider(SMS_API_KEY)
    
    return DevEchoProvider()
