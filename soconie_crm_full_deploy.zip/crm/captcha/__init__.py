"""
CAPTCHA Package for Soconie CRM.
Provides Slider Puzzle CAPTCHA generator, validator, and provider interfaces.
"""
from crm.captcha.generator import generate_puzzle_challenge, get_available_images
from crm.captcha.provider import get_captcha_provider, CaptchaProvider
