"""
CAPTCHA API Routes for Soconie CRM.
Exposes endpoints to create, verify, and test slider puzzle challenges.
"""
from flask import Blueprint, request, jsonify, render_template, make_response
from crm.captcha.provider import get_captcha_provider
from crm.captcha.generator import get_available_images, generate_puzzle_challenge
from crm.site_config import CAPTCHA_ASSETS_DIR

captcha_bp = Blueprint("captcha", __name__)


def get_client_ip() -> str:
    """Extracts client IP safely from request headers."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.remote_addr or "127.0.0.1"


@captcha_bp.route("/api/captcha/challenge", methods=["GET", "POST"])
def get_challenge():
    """
    Creates a new CAPTCHA challenge without exposing original image or coordinates.
    Strictly sets Cache-Control: no-store.
    """
    data = request.get_json(silent=True) or request.args
    action = data.get("action", "register")
    ip_address = get_client_ip()

    provider = get_captcha_provider()
    payload = provider.create_challenge(action=action, ip_address=ip_address)

    response = make_response(jsonify(payload))
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    return response


@captcha_bp.route("/api/captcha/verify", methods=["POST"])
def verify_challenge():
    """
    Verifies client drag coordinates, trajectory, or accessibility fallback answer.
    Issues single-use token on success.
    """
    data = request.get_json(silent=True) or request.form
    ip_address = get_client_ip()

    provider = get_captcha_provider()
    result = provider.verify(payload=data, ip_address=ip_address)

    status_code = 200 if result.get("success") else 400
    response = make_response(jsonify(result), status_code)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return response


@captcha_bp.route("/dev/captcha-test", methods=["GET"])
def dev_test_page():
    """
    Dedicated developer verification page.
    Generates 20 consecutive challenges to inspect randomness, distribution,
    high-contrast edge placement, and both Light / Dark theme compatibility.
    """
    images = get_available_images()
    
    # Generate 20 test challenges
    test_challenges = []
    for i in range(20):
        c = generate_puzzle_challenge()
        test_challenges.append({
            "index": i + 1,
            "id": c["challenge_id"],
            "correct_x": c["correct_x"],
            "correct_y": c["correct_y"],
            "bg_image": c["bg_image"],
            "piece_image": c["piece_image"],
            "y": c["piece_y"],
            "w": c["piece_w"],
            "h": c["piece_h"],
            "fallback_q": c["fallback_question"],
            "fallback_a": c["fallback_answer"]
        })

    return render_template(
        "system/captcha_dev_test.html",
        challenges=test_challenges,
        total_images=len(images),
        assets_dir=CAPTCHA_ASSETS_DIR
    )
