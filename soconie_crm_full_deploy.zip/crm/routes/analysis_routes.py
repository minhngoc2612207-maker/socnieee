"""
Analysis Studio and Contact API Routes for Soconie CRM.
Exposes endpoints for the 5-step Data Analysis Workspace and Landing Contact Form.
"""
import os
import json
import uuid
from datetime import datetime
from flask import (
    Blueprint, request, jsonify, render_template,
    send_file, session, url_for, redirect, flash
)

from crm.auth import get_current_user, login_required
from crm.database import query_db, execute_db
from crm.captcha.validator import consume_captcha_token
from crm.services.analysis_engine import (
    get_sample_dataset,
    get_crm_internal_dataset,
    parse_google_sheets_url,
    parse_uploaded_file,
    audit_data_quality,
    clean_dataset_with_rules,
    run_ai_qa_query,
    execute_ai_card_tool,
    compute_crm_analytics,
    export_clean_excel,
    export_word_report,
    export_markdown_report
)

analysis_bp = Blueprint("analysis", __name__)


# =====================================================================
# 1. VIEW: KHÔNG GIAN PHÂN TÍCH (4 BƯỚC CHUẨN KHỚP DEMO AGENT & SOCONIE CRM)
# =====================================================================

@analysis_bp.route("/khong-gian-phan-tich")
def analysis_studio_root():
    """Redirects to Step 1 of the 4-step workbench."""
    return redirect("/phan-tich/buoc-1")


@analysis_bp.route("/phan-tich/buoc-<int:step_num>")
def analysis_studio_page(step_num=1):
    """
    Renders the 4-step Analysis Studio window matching reference layout 1:1.
    Steps:
      1: Kết nối (Chọn nguồn dữ liệu)
      2: Làm sạch (Kiểm tra và chuẩn hóa)
      3: Phân tích (Khám phá số liệu)
      4: Báo cáo (Xem kết quả và xuất tệp)
    """
    user = get_current_user()
    step_val = max(1, min(4, step_num if step_num is not None else 1))

    # Sequential unlocking calculation (1..4)
    unlocked_step = session.get("analysis_unlocked_step", 1)

    # Read cookie to persist progress across browser reloads
    cookie_unlocked = request.cookies.get("soconie_unlocked_step")
    if cookie_unlocked:
        try:
            unlocked_step = max(unlocked_step, int(cookie_unlocked))
        except (ValueError, TypeError):
            pass

    if session.get("analysis_data"):
        unlocked_step = max(unlocked_step, 2)
    if session.get("analysis_cleaned_data"):
        unlocked_step = max(unlocked_step, 3)
    if session.get("analysis_report_ready"):
        unlocked_step = max(unlocked_step, 4)

    # Route guard: prevent jumping ahead to locked steps unless unlocked
    if step_val > unlocked_step and not request.args.get("unlock_all"):
        return redirect(f"/phan-tich/buoc-{unlocked_step}")

    resp = render_template(
        "analysis/studio.html",
        current_user=user,
        initial_step=str(step_val),
        unlocked_step=unlocked_step,
        active_page="analysis"
    )
    return resp


@analysis_bp.route("/api/analysis/unlock-step", methods=["POST"])
def api_unlock_step():
    """Unlocks a step and persists in session & cookie."""
    try:
        data = request.get_json(silent=True) or {}
        step = int(data.get("step", 1))
        cur = session.get("analysis_unlocked_step", 1)
        session["analysis_unlocked_step"] = max(cur, step)
        if step >= 2:
            session["analysis_data"] = session.get("analysis_data") or True
        if step >= 3:
            session["analysis_cleaned_data"] = session.get("analysis_cleaned_data") or True
        if step >= 4:
            session["analysis_report_ready"] = True
        session.modified = True

        resp = jsonify({"success": True, "unlocked_step": session["analysis_unlocked_step"]})
        resp.set_cookie("soconie_unlocked_step", str(session["analysis_unlocked_step"]), max_age=86400 * 7, path="/", samesite="Lax")
        return resp
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 400


@analysis_bp.route("/api/analysis/reset", methods=["POST"])
def api_analysis_reset():
    """Resets studio session back to step 1."""
    session.pop("analysis_unlocked_step", None)
    session.pop("analysis_data", None)
    session.pop("analysis_cleaned_data", None)
    session.pop("analysis_report_ready", None)
    session.modified = True
    resp = jsonify({"success": True})
    resp.set_cookie("soconie_unlocked_step", "1", max_age=86400 * 7, path="/", samesite="Lax")
    return resp


# =====================================================================
# 2. API NẠP DỮ LIỆU (BƯỚC 1)
# =====================================================================

@analysis_bp.route("/api/analysis/load-sample", methods=["POST"])
def api_load_sample():
    """Loads default CRM sample dataset (Doanh thu & Marketing 2026)."""
    try:
        result = get_sample_dataset()
        session["analysis_data"] = result["raw_data"]
        session["analysis_source"] = result["source_name"]
        return jsonify(result)
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 400


@analysis_bp.route("/api/analysis/load-crm", methods=["POST"])
def api_load_crm():
    """Loads internal SQLite CRM customer & pipeline data."""
    try:
        result = get_crm_internal_dataset()
        session["analysis_data"] = result["raw_data"]
        session["analysis_source"] = result["source_name"]
        return jsonify(result)
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 400


@analysis_bp.route("/api/analysis/google-sheets", methods=["POST"])
def api_google_sheets():
    """Fetches and parses public Google Sheets CSV."""
    data = request.get_json(silent=True) or request.form
    url = data.get("url", "").strip()
    if not url:
        return jsonify({"success": False, "message": "Vui lòng nhập đường liên kết Google Sheets!"}), 400

    try:
        result = parse_google_sheets_url(url)
        session["analysis_data"] = result["raw_data"]
        session["analysis_source"] = result["source_name"]
        return jsonify(result)
    except ValueError as ve:
        return jsonify({"success": False, "message": str(ve)}), 400
    except Exception as e:
        return jsonify({"success": False, "message": f"Lỗi không xác định khi kết nối Google Sheets: {str(e)}"}), 500


@analysis_bp.route("/api/analysis/upload", methods=["POST"])
def api_upload_file():
    """Handles CSV, TSV, or Excel file upload with 20MB limit."""
    if "file" not in request.files:
        return jsonify({"success": False, "message": "Không tìm thấy tệp tải lên."}), 400

    f = request.files["file"]
    if f.filename == "":
        return jsonify({"success": False, "message": "Chưa chọn tệp nào."}), 400

    try:
        result = parse_uploaded_file(f)
        session["analysis_data"] = result["raw_data"]
        session["analysis_source"] = result["source_name"]
        return jsonify(result)
    except ValueError as ve:
        return jsonify({"success": False, "message": str(ve)}), 400
    except Exception as e:
        return jsonify({"success": False, "message": f"Lỗi xử lý tệp: {str(e)}"}), 500


# =====================================================================
# 3. API KIỂM TRA CHẤT LƯỢNG & LÀM SẠCH (BƯỚC 2)
# =====================================================================

@analysis_bp.route("/api/analysis/audit", methods=["POST"])
def api_audit():
    """Runs data quality diagnostics (missing, duplicates, blanks, outliers, format)."""
    payload = request.get_json(silent=True) or {}
    raw_data = payload.get("data") or session.get("analysis_data")
    if not raw_data:
        return jsonify({"success": False, "message": "Chưa có dữ liệu để kiểm tra."}), 400

    quality = audit_data_quality(raw_data)
    return jsonify({"success": True, "quality": quality})


@analysis_bp.route("/api/analysis/clean", methods=["POST"])
def api_clean():
    """Applies rule-based data cleaning and generates diffs for Before/After preview."""
    payload = request.get_json(silent=True) or {}
    raw_data = payload.get("data") or session.get("analysis_data")
    rules = payload.get("rules") or {}

    if not raw_data:
        return jsonify({"success": False, "message": "Chưa có dữ liệu để làm sạch."}), 400

    clean_res = clean_dataset_with_rules(raw_data, rules)
    session["analysis_cleaned_data"] = clean_res["cleaned_data"]
    return jsonify(clean_res)


# =====================================================================
# 4. API TRỢ LÝ AI & SMART TOOLS (BƯỚC 3)
# =====================================================================

@analysis_bp.route("/api/analysis/ai-chat", methods=["POST"])
def api_ai_chat():
    """Q&A assistant strictly grounded in the cleaned dataset."""
    payload = request.get_json(silent=True) or {}
    query = payload.get("query", "").strip()
    data = payload.get("data") or session.get("analysis_cleaned_data") or session.get("analysis_data")
    
    if not query:
        return jsonify({"success": False, "message": "Vui lòng nhập câu hỏi."}), 400
    if not data:
        return jsonify({"success": False, "message": "Chưa có dữ liệu để phân tích."}), 400

    resp = run_ai_qa_query(data, query)
    return jsonify({"success": True, "result": resp})


@analysis_bp.route("/api/analysis/ai-tool", methods=["POST"])
def api_ai_tool():
    """Executes smart card tools (dictionary, suggestions, anomaly, narrative, customer care)."""
    payload = request.get_json(silent=True) or {}
    tool_type = payload.get("tool_type", "data_dictionary")
    data = payload.get("data") or session.get("analysis_cleaned_data") or session.get("analysis_data")

    if not data:
        return jsonify({"success": False, "message": "Chưa có dữ liệu để chạy công cụ."}), 400

    resp = execute_ai_card_tool(tool_type, data)
    return jsonify({"success": True, "result": resp})


# =====================================================================
# 5. API PHÂN TÍCH CHUYÊN SÂU (BƯỚC 4)
# =====================================================================

@analysis_bp.route("/api/analysis/compute", methods=["POST"])
def api_compute():
    """Computes descriptive stats, funnel stages, Pareto distribution, and recommendations."""
    payload = request.get_json(silent=True) or {}
    data = payload.get("data") or session.get("analysis_cleaned_data") or session.get("analysis_data")

    if not data:
        return jsonify({"success": False, "message": "Chưa có dữ liệu để phân tích."}), 400

    analytics = compute_crm_analytics(data)
    session["analysis_analytics"] = analytics
    return jsonify(analytics)


# =====================================================================
# 6. API XUẤT TỆP & LƯU BÁO CÁO (BƯỚC 5)
# =====================================================================

@analysis_bp.route("/api/analysis/export", methods=["POST"])
def api_export():
    """Exports to Excel (.xlsx), Word (.docx), Markdown (.md), or JSON."""
    payload = request.get_json(silent=True) or request.form
    export_format = payload.get("format", "excel_clean").lower()
    data = payload.get("data") or session.get("analysis_cleaned_data") or session.get("analysis_data")
    analytics = payload.get("analytics") or session.get("analysis_analytics") or {}
    title = payload.get("title", "Báo Cáo Phân Tích Kinh Doanh Soconie CRM")
    summary = payload.get("summary", "")
    pinned_notes = payload.get("pinned_notes", [])

    if not data:
        return jsonify({"success": False, "message": "Không có dữ liệu để xuất tệp."}), 400

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    if export_format in ["excel_clean", "xlsx"]:
        excel_io = export_clean_excel(data)
        return send_file(
            excel_io,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            as_attachment=True,
            download_name=f"Soconie_DuLieuSach_{timestamp}.xlsx"
        )
    elif export_format in ["word", "docx"]:
        if not analytics:
            analytics = compute_crm_analytics(data)
        doc_io = export_word_report(title, summary, analytics, pinned_notes)
        return send_file(
            doc_io,
            mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            as_attachment=True,
            download_name=f"Soconie_BaoCao_{timestamp}.docx"
        )
    elif export_format in ["markdown", "md"]:
        if not analytics:
            analytics = compute_crm_analytics(data)
        md_text = export_markdown_report(title, summary, analytics)
        return send_file(
            io.BytesIO(md_text.encode("utf-8")),
            mimetype="text/markdown",
            as_attachment=True,
            download_name=f"Soconie_BaoCao_{timestamp}.md"
        )
    elif export_format in ["audit", "json"]:
        audit_json = json.dumps({
            "generated_at": datetime.now().isoformat(),
            "system": "Soconie CRM - Lê Minh Ngọc",
            "total_records": len(data),
            "analytics_summary": analytics.get("kpis", {})
        }, ensure_ascii=False, indent=2)
        return send_file(
            io.BytesIO(audit_json.encode("utf-8")),
            mimetype="application/json",
            as_attachment=True,
            download_name=f"Soconie_NhatKyKiemTra_{timestamp}.json"
        )
    else:
        return jsonify({"success": False, "message": f"Định dạng xuất '{export_format}' không hợp lệ."}), 400


@analysis_bp.route("/api/analysis/save-report", methods=["POST"])
def api_save_report():
    """Saves user analysis report to SQLite for future reference."""
    user = get_current_user()
    user_id = user["id"] if user else None
    payload = request.get_json(silent=True) or {}
    title = payload.get("title", "Báo cáo phân tích kinh doanh")
    summary = payload.get("summary", "")
    dataset_name = payload.get("dataset_name", "dataset.csv")
    report_data = json.dumps(payload.get("report_data", {}), ensure_ascii=False)

    report_id = f"rep_{uuid.uuid4().hex[:12]}"
    share_token = uuid.uuid4().hex[:16]
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    execute_db("""
        INSERT INTO analysis_reports (id, user_id, title, summary, dataset_name, report_data, share_token, is_public, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    """, (report_id, user_id, title, summary, dataset_name, report_data, share_token, now_str, now_str))

    share_url = url_for("analysis.shared_report_view", share_token=share_token, _external=True)
    return jsonify({
        "success": True,
        "report_id": report_id,
        "share_token": share_token,
        "share_url": share_url,
        "message": "Báo cáo đã được lưu thành công vào không gian của bạn!"
    })


@analysis_bp.route("/bao-cao/chia-se/<share_token>")
def shared_report_view(share_token):
    """Read-only view for shared reports."""
    report = query_db("SELECT * FROM analysis_reports WHERE share_token = ?", (share_token,), one=True)
    if not report:
        flash("Liên kết báo cáo không tồn tại hoặc đã hết hạn.", "warning")
        return redirect(url_for("dashboard.landing_home"))

    report_data = json.loads(report["report_data"]) if report["report_data"] else {}
    return render_template(
        "analysis/shared_report.html",
        report=report,
        report_data=report_data
    )


# =====================================================================
# 7. API FORM LIÊN HỆ TRANG CHỦ (#lien-he)
# =====================================================================

@analysis_bp.route("/api/contact", methods=["POST"])
def api_contact():
    """
    Submits contact inquiry with full name, contact (phone/email), need, message,
    and verified Slider Puzzle CAPTCHA token.
    """
    data = request.get_json(silent=True) or request.form
    full_name = data.get("full_name", "").strip()
    contact = data.get("contact", "").strip()
    need = data.get("need", "").strip()
    message = data.get("message", "").strip()
    terms_agreed = bool(data.get("terms", False))
    captcha_token = data.get("captcha_token", "").strip()
    
    forwarded = request.headers.get("X-Forwarded-For")
    ip_address = forwarded.split(",")[0].strip() if forwarded else (request.remote_addr or "127.0.0.1")

    # 1. Basic validation
    if not full_name:
        return jsonify({"success": False, "message": "Vui lòng nhập họ và tên của bạn!"}), 400
    if not contact:
        return jsonify({"success": False, "message": "Vui lòng nhập số điện thoại hoặc email liên hệ!"}), 400
    if not terms_agreed:
        return jsonify({"success": False, "message": "Vui lòng tích đồng ý điều khoản bảo mật trước khi gửi!"}), 400

    # 2. CAPTCHA verification
    if not consume_captcha_token(captcha_token, "contact", ip_address):
        return jsonify({
            "success": False,
            "message": "Xác nhận CAPTCHA không hợp lệ hoặc đã hết hạn. Vui lòng kéo ghép hình lại!"
        }), 400

    # 3. Store inquiry in DB
    inquiry_id = f"inq_{uuid.uuid4().hex[:12]}"
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    execute_db("""
        INSERT INTO contact_inquiries (id, full_name, contact, need, message, ip_address, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, 'new', ?)
    """, (inquiry_id, full_name, contact, need, message, ip_address, now_str))

    return jsonify({
        "success": True,
        "message": "Cảm ơn bạn! Lê Minh Ngọc sẽ phản hồi qua email hoặc số điện thoại bạn để lại."
    })

