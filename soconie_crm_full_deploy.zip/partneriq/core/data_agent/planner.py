"""
B2.3 Semantic Planner (DataIQ)
Leverages Google Gemini (or expert heuristic fallback) to interpret business context,
map columns to business semantics, and produce a structured, validated JSON execution plan.
Incorporate Workspace Lessons Learned into prompt context.
"""

import json
import re
from typing import Dict, Any, List, Optional, Tuple
from agent.llm_client import call_gemini


PLANNER_SYSTEM_PROMPT = """
Bạn là Chuyên gia Kiến trúc Dữ liệu & Phân tích Kinh doanh Cấp cao.
Nhiệm vụ của bạn là đọc Bối cảnh doanh nghiệp, Vấn đề cần giải quyết, Hồ sơ thống kê dữ liệu (Profiling)
và các Bài học kinh nghiệm đã tích lũy (Lessons Learned) để lập một KẾ HOẠCH XỬ LÝ DỮ LIỆU ĐO LƯỜNG CHÍNH XÁC.

YÊU CẦU ĐẦU RA BẮT BUỘC: Đúng định dạng JSON tuân thủ schema sau (không giải thích dông dài):
{
  "confidence_overall": 0.95,
  "summary_plan": "Mô tả ngắn gọn chiến lược làm sạch và phân tích bài toán trong 2 câu.",
  "column_mappings": [
    {
      "column_name": "Tên cột gốc trong file",
      "business_role": "TRANSACTION_ID | DATE | PARTNER_ID | PARTNER_NAME | TAX_ID | PHONE | PRODUCT_NAME | CATEGORY | QUANTITY | UNIT_PRICE | TOTAL_AMOUNT | DEBT_BALANCE | STATUS | OTHER",
      "semantic_meaning": "Ý nghĩa kinh doanh cụ thể",
      "confidence": 0.9
    }
  ],
  "cleaning_rules": {
    "date_columns": ["col1"],
    "numeric_columns": ["col2"],
    "phone_columns": ["col3"],
    "tax_id_columns": ["col4"],
    "missing_value_strategy": [
      {"column": "col", "strategy": "median | mode | flag_unknown | drop_if_all_null", "default_value": "..."}
    ]
  },
  "deduplication_rules": {
    "exact_keys": [["colA", "colB"]],
    "fuzzy_keys": [
      {"column": "col_name", "threshold": 85, "note": "Phát hiện đại lý trùng lặp do viết tắt hoặc thêm đuôi chi nhánh"}
    ]
  },
  "outlier_rules": {
    "numeric_columns": ["col_money"],
    "method": "IQR",
    "multiplier": 1.5
  },
  "logic_rules": [
    {
      "rule_id": "LOGIC-01",
      "description": "Kiểm tra Thành tiền = Số lượng * Đơn giá",
      "type": "EQUALITY_PRODUCT",
      "total_col": "Thanh_Tien",
      "qty_col": "So_Luong",
      "price_col": "Don_Gia",
      "tolerance_pct": 0.05
    },
    {
      "rule_id": "LOGIC-02",
      "description": "Số lượng và Đơn giá không được âm",
      "type": "NON_NEGATIVE",
      "columns": ["So_Luong", "Don_Gia"]
    }
  ],
  "analysis_plan": {
    "primary_metrics": ["Doanh thu tổng", "Doanh thu sau hiệu chỉnh", "Tỷ lệ sai sót logic"],
    "dimension_groups": ["Khu_Vuc", "San_Pham", "Ten_Dai_Ly"],
    "anomalies_to_flag": ["Giao dịch ngoại lai trên 5 tỷ", "Trùng lặp tên đại lý", "Sai lệch công nợ"]
  }
}
"""


def generate_heuristic_plan(
    business_context: Dict[str, Any],
    problem_statement: str,
    profiling_summary: Dict[str, Any],
    column_descriptions: Optional[Dict[str, str]] = None,
    lessons: Optional[List[Dict[str, Any]]] = None
) -> Dict[str, Any]:
    """
    Expert deterministic heuristic planner.
    Used as instant fallback if Gemini is unreachable or API key is absent.
    """
    col_descs = column_descriptions or {}
    lessons_list = lessons or []

    # Collect all available columns from datasets
    all_cols = []
    datasets = profiling_summary.get("datasets", {})
    for ds_name, ds_info in datasets.items():
        for col_name, c_stats in ds_info.get("columns", {}).items():
            all_cols.append((col_name, c_stats))

    mappings = []
    date_cols = []
    numeric_cols = []
    phone_cols = []
    tax_cols = []
    missing_strats = []
    exact_keys = []
    fuzzy_keys = []
    outlier_cols = []
    logic_rules = []

    # Match patterns
    for col, stats in all_cols:
        c_clean = col.lower().strip().replace(" ", "_")
        role = "OTHER"
        confidence = 0.8

        # Check user-supplied description
        if col in col_descs:
            desc = col_descs[col].lower()
            if "doanh thu" in desc or "tiền" in desc:
                role = "TOTAL_AMOUNT"
            elif "số lượng" in desc:
                role = "QUANTITY"
            elif "đơn giá" in desc:
                role = "UNIT_PRICE"

        # Check lessons learned
        for l in lessons_list:
            if l.get("rule_key", "").endswith(col.lower()):
                confidence = 0.99

        if role == "OTHER":
            if any(k in c_clean for k in ["ma_don", "order_id", "invoice_no", "so_ct"]):
                role = "TRANSACTION_ID"
            elif any(k in c_clean for k in ["ngay", "date", "time", "thoi_gian"]):
                role = "DATE"
                date_cols.append(col)
            elif any(k in c_clean for k in ["ma_dai_ly", "ma_kh", "cust_id", "partner_id"]):
                role = "PARTNER_ID"
            elif any(k in c_clean for k in ["ten_dai_ly", "ten_kh", "customer", "partner_name", "cong_ty"]):
                role = "PARTNER_NAME"
                fuzzy_keys.append({"column": col, "threshold": 85, "note": "Phát hiện đại lý trùng lặp mờ"})
            elif any(k in c_clean for k in ["mst", "tax"]):
                role = "TAX_ID"
                tax_cols.append(col)
            elif any(k in c_clean for k in ["sdt", "phone", "tel", "mobile"]):
                role = "PHONE"
                phone_cols.append(col)
            elif any(k in c_clean for k in ["san_pham", "product", "item", "hang_hoa"]):
                role = "PRODUCT_NAME"
            elif any(k in c_clean for k in ["khu_vuc", "region", "dia_ban", "nhom"]):
                role = "CATEGORY"
            elif any(k in c_clean for k in ["so_luong", "qty", "quantity"]):
                role = "QUANTITY"
                numeric_cols.append(col)
            elif any(k in c_clean for k in ["don_gia", "unit_price", "price", "gia_ban"]):
                role = "UNIT_PRICE"
                numeric_cols.append(col)
            elif any(k in c_clean for k in ["thanh_tien", "doanh_thu", "total", "amount", "revenue"]):
                role = "TOTAL_AMOUNT"
                numeric_cols.append(col)
                outlier_cols.append(col)
            elif any(k in c_clean for k in ["cong_no", "debt", "balance", "du_no"]):
                role = "DEBT_BALANCE"
                numeric_cols.append(col)
            elif any(k in c_clean for k in ["trang_thai", "status"]):
                role = "STATUS"
            elif stats.get("type") == "numeric":
                numeric_cols.append(col)

        mappings.append({
            "column_name": col,
            "business_role": role,
            "semantic_meaning": f"Cột {col} ánh xạ theo nhận diện nghiệp vụ",
            "confidence": confidence
        })

        if stats.get("null_count", 0) > 0:
            if role in ["QUANTITY", "UNIT_PRICE", "TOTAL_AMOUNT"]:
                missing_strats.append({"column": col, "strategy": "median", "default_value": "0"})
            elif role in ["PARTNER_NAME", "PRODUCT_NAME", "CATEGORY"]:
                missing_strats.append({"column": col, "strategy": "flag_unknown", "default_value": "CHƯA XÁC ĐỊNH"})

    # Primary key deduplication
    tx_cols = [m["column_name"] for m in mappings if m["business_role"] == "TRANSACTION_ID"]
    if tx_cols:
        exact_keys.append(tx_cols)

    # Cross logic rule check: Total == Qty * Price
    total_cols = [m["column_name"] for m in mappings if m["business_role"] == "TOTAL_AMOUNT"]
    qty_cols = [m["column_name"] for m in mappings if m["business_role"] == "QUANTITY"]
    price_cols = [m["column_name"] for m in mappings if m["business_role"] == "UNIT_PRICE"]

    if total_cols and qty_cols and price_cols:
        logic_rules.append({
            "rule_id": "LOGIC-PROD-01",
            "description": f"Kiểm tra tính nhất quán: {total_cols[0]} = {qty_cols[0]} * {price_cols[0]}",
            "type": "EQUALITY_PRODUCT",
            "total_col": total_cols[0],
            "qty_col": qty_cols[0],
            "price_col": price_cols[0],
            "tolerance_pct": 0.05
        })

    return {
        "confidence_overall": 0.88,
        "summary_plan": "Kế hoạch xử lý theo bộ luật xác định: chuẩn hóa định dạng ngày/tiền tệ/SĐT/MST, khử trùng lặp giao dịch và đại lý mờ, kiểm soát ngoại lai IQR và kiểm tra toán học giữa các cột nghiệp vụ.",
        "column_mappings": mappings,
        "cleaning_rules": {
            "date_columns": list(set(date_cols)),
            "numeric_columns": list(set(numeric_cols)),
            "phone_columns": list(set(phone_cols)),
            "tax_id_columns": list(set(tax_cols)),
            "missing_value_strategy": missing_strats
        },
        "deduplication_rules": {
            "exact_keys": exact_keys or [[all_cols[0][0]]] if all_cols else [],
            "fuzzy_keys": fuzzy_keys
        },
        "outlier_rules": {
            "numeric_columns": list(set(outlier_cols or numeric_cols)),
            "method": "IQR",
            "multiplier": 1.5
        },
        "logic_rules": logic_rules,
        "analysis_plan": {
            "primary_metrics": ["Tổng doanh thu", "Doanh thu sau hiệu chỉnh", "Số dòng sai lệch"],
            "dimension_groups": [m["column_name"] for m in mappings if m["business_role"] in ["CATEGORY", "PRODUCT_NAME", "PARTNER_NAME"]],
            "anomalies_to_flag": ["Giao dịch ngoại lai", "Trùng lặp đại lý", "Sai lệch công nợ"]
        }
    }


def create_processing_plan(
    business_context: Dict[str, Any],
    problem_statement: str,
    goals: List[str],
    profiling_summary: Dict[str, Any],
    column_descriptions: Optional[Dict[str, str]] = None,
    lessons: Optional[List[Dict[str, Any]]] = None
) -> Tuple[Dict[str, Any], str]:
    """
    Orchestrates plan creation:
    1. Calls Gemini with rich business prompt and schema.
    2. Falls back to deterministic heuristic plan if Gemini call fails.
    Returns: (plan_dict, source_badge: 'GEMINI_AI' | 'DETERMINISTIC_FALLBACK')
    """
    lessons_ctx = ""
    if lessons:
        lessons_ctx = "\n=== CÁC BÀI HỌC KINH NGHIỆM ĐÃ TÍCH LŨY TỪ WORKSPACE (PHẢI TUÂN THỦ) ===\n"
        for idx, l in enumerate(lessons, 1):
            lessons_ctx += f"{idx}. [{l.get('category')}] {l.get('rule_key')}: {l.get('rule_content')}\n"

    prompt = f"""
BỐI CẢNH DOANH NGHIỆP:
- Ngành hàng: {business_context.get('industry', 'Thương mại')}
- Quy mô: {business_context.get('scale', 'Vừa và nhỏ')}
- Mô hình: {business_context.get('business_model', 'B2B')}

VẤN ĐỀ NGƯỜI DÙNG ĐẶT RA:
"{problem_statement}"

MỤC TIÊU MONG MUỐN: {', '.join(goals)}

MÔ TẢ CỘT CỦA NGƯỜI DÙNG:
{json.dumps(column_descriptions or {}, ensure_ascii=False, indent=2)}

{lessons_ctx}

TỔNG QUAN DỮ LIỆU ĐÃ PROFILING (CHỈ GỬI SỐ LIỆU TÓM TẮT & ĐÃ CHE DỮ LIỆU NHẠY CẢM):
{json.dumps(profiling_summary, ensure_ascii=False, indent=2)}

Hãy lập Kế hoạch Xử lý Dữ liệu chuẩn xác theo cấu trúc JSON được yêu cầu.
"""

    gemini_res = call_gemini(
        prompt=prompt,
        system_instruction=PLANNER_SYSTEM_PROMPT,
        json_mode=True,
        temperature=0.1
    )

    if gemini_res.get("success") and gemini_res.get("data") and isinstance(gemini_res["data"], dict):
        plan = gemini_res["data"]
        # Basic validation of plan
        if "column_mappings" in plan and "cleaning_rules" in plan:
            return plan, "GEMINI_AI"

    # Fallback to heuristic
    plan = generate_heuristic_plan(
        business_context=business_context,
        problem_statement=problem_statement,
        profiling_summary=profiling_summary,
        column_descriptions=column_descriptions,
        lessons=lessons
    )
    return plan, "DETERMINISTIC_FALLBACK"
