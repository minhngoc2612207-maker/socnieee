"""
Job Manager & State Machine Orchestrator (DataIQ)
Coordinates the complete B1 -> B7 AI Agent workflow.
Manages states: DRAFT -> PROCESSING -> FAILED / READY_FOR_REVIEW -> REPROCESSING -> REVIEWED -> EXPORTED.
Runs heavy processing in background threads with cancellation support and real-time progress events.
"""

import os
import json
import time
import threading
from datetime import datetime
from typing import Dict, Any, List, Optional

import pandas as pd

from partneriq.repository import (
    get_job, update_job_status, update_job_progress, get_job_files,
    create_run, add_change_logs, add_findings, add_error_reports,
    get_workspace, log_audit, get_active_lessons
)
from partneriq.core.data_agent.reader import read_all_job_files
from partneriq.core.data_agent.profiler import profile_all_datasets
from partneriq.core.data_agent.planner import create_processing_plan
from partneriq.core.data_agent.gatekeeper import evaluate_gatekeeper_decision
from partneriq.core.data_agent.processor import execute_data_processing
from partneriq.core.data_agent.analyzer import analyze_business_data, generate_executive_report
from partneriq.core.data_agent.error_reporter import build_error_summary, generate_friendly_explanation

# Registry for cancellation flags and active in-memory datasets
CANCEL_FLAGS: Dict[str, bool] = {}
DATASET_CACHE: Dict[str, Dict[str, pd.DataFrame]] = {}


def is_job_cancelled(job_id: str) -> bool:
    return CANCEL_FLAGS.get(job_id, False)


def cancel_job(job_id: str, user_name: str = "staff") -> bool:
    """Signals background worker to halt execution immediately."""
    CANCEL_FLAGS[job_id] = True
    job = get_job(job_id)
    if job and job.get("status") in ["PROCESSING", "REPROCESSING"]:
        update_job_status(job_id, "FAILED", "Đã hủy bởi người dùng", user_name=user_name)
        log_audit(
            workspace_id=job.get("workspace_id", "ws-default"),
            action="CANCEL_JOB",
            target_type="JOB",
            target_id=job_id,
            user_name=user_name,
            details="Người dùng chủ động hủy bỏ tiến trình xử lý."
        )
        return True
    return False


def start_job_pipeline_async(job_id: str, user_name: str = "staff"):
    """Starts the full data pipeline in a daemon thread, or synchronously on serverless."""
    CANCEL_FLAGS[job_id] = False
    is_serverless = bool(
        os.environ.get("VERCEL") or
        os.environ.get("AWS_LAMBDA_FUNCTION_NAME") or
        os.environ.get("VERCEL_ENV")
    )
    if is_serverless:
        # On Vercel serverless, background threads are frozen when response ends.
        # Run synchronously so data is ready immediately.
        _run_pipeline_worker(job_id, user_name)
    else:
        thread = threading.Thread(
            target=_run_pipeline_worker,
            args=(job_id, user_name),
            daemon=True,
            name=f"DataIQ-Worker-{job_id}"
        )
        thread.start()


def _run_pipeline_worker(job_id: str, user_name: str = "staff"):
    """Background worker executing B2 -> B3 -> B4/B5."""
    try:
        job = get_job(job_id)
        if not job:
            return

        workspace_id = job.get("workspace_id", "ws-default")
        ws = get_workspace(workspace_id)
        ws_cfg = ws.get("config", {}) if ws else {}

        # -------------------------------------------------------------
        # Step 1: Read Files (15%)
        # -------------------------------------------------------------
        update_job_progress(job_id, 10, "B2.1: Đang đọc và nhận diện tệp dữ liệu...")
        if is_job_cancelled(job_id):
            return

        file_records = get_job_files(job_id)
        raw_datasets, read_errors = read_all_job_files(file_records)
        DATASET_CACHE[job_id] = raw_datasets

        time.sleep(0.3)  # Smooth transition for progress bar
        update_job_progress(job_id, 25, f"B2.1: Đã nạp {len(raw_datasets)} bảng dữ liệu.")

        if is_job_cancelled(job_id):
            return

        # -------------------------------------------------------------
        # Step 2: Profiling & PII Masking (35%)
        # -------------------------------------------------------------
        update_job_progress(job_id, 35, "B2.2: Đang thống kê cấu trúc & che dữ liệu nhạy cảm...")
        mask_pii = bool(job.get("mask_sensitive", 1))
        profiling = profile_all_datasets(raw_datasets, mask_sensitive=mask_pii)

        time.sleep(0.3)
        if is_job_cancelled(job_id):
            return

        # -------------------------------------------------------------
        # Step 3: Semantic Plan via Gemini / Heuristics (50%)
        # -------------------------------------------------------------
        update_job_progress(job_id, 50, "B2.3: Gemini đang phân tích bối cảnh & lập kế hoạch xử lý...")
        active_lessons = get_active_lessons(workspace_id)

        plan, plan_source = create_processing_plan(
            business_context=job.get("business_context", {}),
            problem_statement=job.get("problem_statement", ""),
            goals=job.get("goals", []),
            profiling_summary=profiling,
            column_descriptions=job.get("column_descriptions", {}),
            lessons=active_lessons
        )

        time.sleep(0.3)
        if is_job_cancelled(job_id):
            return

        # -------------------------------------------------------------
        # Step 4: Decision Gatekeeper (60%)
        # -------------------------------------------------------------
        update_job_progress(job_id, 60, "B3: Cổng quyết định chất lượng (Gatekeeper) đang thẩm định...")
        decision, gate_notes, gate_errors = evaluate_gatekeeper_decision(
            read_errors=read_errors,
            raw_datasets=raw_datasets,
            plan=plan,
            workspace_config=ws_cfg
        )

        # -------------------------------------------------------------
        # BRANCH B4: CANNOT_PROCESS (FAILED)
        # -------------------------------------------------------------
        if decision == "CANNOT_PROCESS":
            for ge in gate_errors:
                ge["job_id"] = job_id
                ge["workspace_id"] = workspace_id
            add_error_reports(gate_errors)
            friendly_help = generate_friendly_explanation(gate_errors, job.get("problem_statement", ""))
            err_summary = build_error_summary(gate_errors)
            err_summary["friendly_help"] = friendly_help

            update_job_status(
                job_id=job_id,
                new_status="FAILED",
                current_stage=f"B4: Thất bại - {gate_notes}",
                error_summary=err_summary,
                user_name="Gatekeeper"
            )
            update_job_progress(job_id, 100, "Xử lý kết thúc tại Nhánh Lỗi (B4)")
            return

        # -------------------------------------------------------------
        # BRANCH B5: SUCCESS / PARTIAL -> Clean & Analyze
        # -------------------------------------------------------------
        run_id = f"{job_id}-v1"

        # Step 5: Deterministic Processing (75%)
        update_job_progress(job_id, 75, "B2.4: Đang chuẩn hóa định dạng, khử trùng lặp & phát hiện ngoại lai...")
        clean_datasets, change_logs, proc_metrics = execute_data_processing(
            raw_datasets=raw_datasets,
            plan=plan,
            run_id=run_id,
            job_id=job_id,
            workspace_id=workspace_id
        )
        add_change_logs(change_logs)

        if is_job_cancelled(job_id):
            return

        # Step 6: Problem-driven Business Analysis (85%)
        update_job_progress(job_id, 85, "B2.5: Đang phân tích rủi ro & gắn mã bằng chứng (Evidence Refs)...")
        findings, kpis, chart_data = analyze_business_data(
            clean_datasets=clean_datasets,
            change_logs=change_logs,
            plan=plan,
            problem_statement=job.get("problem_statement", ""),
            business_context=job.get("business_context", {}),
            run_id=run_id,
            job_id=job_id,
            workspace_id=workspace_id
        )
        add_findings(findings)

        if is_job_cancelled(job_id):
            return

        # Step 7: Executive Report Generation (95%)
        update_job_progress(job_id, 95, "B2.6: Đang soạn Báo cáo Điều hành Chiến lược...")
        rep_md, rep_sections, rep_source = generate_executive_report(
            problem_statement=job.get("problem_statement", ""),
            business_context=job.get("business_context", {}),
            findings=findings,
            kpis=kpis,
            change_logs=change_logs
        )

        # Build clean data preview for UI
        first_clean_df = list(clean_datasets.values())[0] if clean_datasets else pd.DataFrame()
        preview_data = {
            "columns": list(first_clean_df.columns),
            "rows": first_clean_df.head(100).to_dict(orient="records"),
            "kpis": kpis,
            "chart_data": chart_data
        }

        # Step 8: Save Run Record v1 & Ready for Review (100%)
        create_run(
            run_id=run_id,
            job_id=job_id,
            workspace_id=workspace_id,
            version=1,
            trigger_type="INITIAL",
            gatekeeper_decision=decision,
            gatekeeper_notes=gate_notes,
            plan_json=plan,
            profiling_json=profiling,
            clean_data_path="",
            clean_data_preview=preview_data,
            report_markdown=rep_md,
            report_sections_json=rep_sections,
            ai_source_badge=rep_source,
            diff_summary_json={},
            reprocess_summary="Khởi tạo xử lý dữ liệu phiên bản v1 ban đầu thành công."
        )

        update_job_status(job_id, "READY_FOR_REVIEW", "B5: Đã sẵn sàng nghiệm thu & phản hồi (v1)", user_name="DataIQ")
        update_job_progress(job_id, 100, "Hoàn tất xử lý - Chuyển sang Mục Nghiệm thu & Phản hồi")

        log_audit(
            workspace_id=workspace_id,
            action="RUN_COMPLETE",
            target_type="JOB",
            target_id=job_id,
            user_name="DataIQ",
            after_state={"status": "READY_FOR_REVIEW", "version": 1, "decision": decision},
            details=f"Hoàn thành xử lý v1: {len(change_logs)} biến đổi, {len(findings)} phát hiện, Doanh thu hiệu chỉnh: {kpis.get('adjusted_revenue', 0):,.0f} đ."
        )

    except Exception as e:
        import traceback
        err_trace = traceback.format_exc()
        print(f"[DataIQ Error] Job {job_id} worker crashed:\n{err_trace}")
        update_job_status(
            job_id=job_id,
            new_status="FAILED",
            current_stage="Lỗi hệ thống trong quá trình xử lý",
            error_summary={
                "total_errors": 1,
                "is_fatal": True,
                "friendly_help": "Đã xảy ra lỗi nội bộ máy chủ khi phân tích tệp dữ liệu. Vui lòng thử lại hoặc liên hệ quản trị viên."
            },
            user_name="system"
        )
