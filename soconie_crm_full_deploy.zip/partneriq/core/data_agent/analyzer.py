"""
B2.5 Problem Analyzer & Strategic Report Generator (DataIQ)
Performs problem-driven business analysis:
- Calculates financial and operational KPIs deterministically.
- Generates structured Findings traceable to exact raw cell coordinates (Evidence Refs).
- Prepares Chart.js visualization datasets.
- Orchestrates Gemini to write the Executive Strategic Assessment (with strict zero-hallucination rules
  and deterministic fallback).
"""

import json
from typing import Dict, Any, List, Tuple, Optional
import pandas as pd
import numpy as np

from agent.llm_client import call_gemini


EXECUTIVE_REPORT_PROMPT = """
Bạn là Cố vấn Chiến lược Cấp cao & Giám đốc Phân tích Dữ liệu Doanh nghiệp.
Hãy viết Báo cáo Điều hành Chiến lược (Executive Strategic Report) bằng Markdown cho Ban Lãnh đạo.

YÊU CẦU BẮT BUỘC:
1. KHÔNG ĐƯỢC TỰ BỊA CON SỐ. Mọi con số trong báo cáo PHẢI lấy từ bảng số liệu thực tế được cung cấp dưới đây.
2. Mỗi nhận định quan trọng PHẢI gắn mã bằng chứng tương ứng (ví dụ: [FIND-001], [FIND-002]).
3. Giọng văn sắc bén, đi thẳng vào bản chất tài chính - vận hành, nêu rõ thiệt hại và giải pháp.
4. Cấu trúc bài viết gồm 4 phần rõ ràng:
   # 1. TÓM TẮT ĐIỀU HÀNH (EXECUTIVE SUMMARY)
   # 2. PHÁT HIỆN TRỌNG TÂM & NGUY CƠ RỦI RO (KEY FINDINGS & EVIDENCE)
   # 3. PHÂN TÍCH NGUYÊN NHÂN GỐC RỄ (ROOT CAUSE ANALYSIS)
   # 4. KHUYẾN NGHỊ HÀNH ĐỘNG CHIẾN LƯỢC (ACTIONABLE RECOMMENDATIONS)
"""


def analyze_business_data(
    clean_datasets: Dict[str, pd.DataFrame],
    change_logs: List[Dict[str, Any]],
    plan: Dict[str, Any],
    problem_statement: str,
    business_context: Dict[str, Any],
    run_id: str,
    job_id: str,
    workspace_id: str = "ws-default"
) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, Any]]:
    """
    Performs deterministic calculations and generates structured findings with evidence refs.
    Returns:
        (findings_list, kpi_metrics, chart_data)
    """
    findings = []
    find_counter = 1

    # Find the main sales or transaction dataset
    main_df = None
    main_ds_name = ""
    for name, df in clean_datasets.items():
        if any(c in df.columns for c in ["Thanh_Tien", "Doanh_Thu", "total", "amount", "revenue"]):
            main_df = df
            main_ds_name = name
            break
    if main_df is None and clean_datasets:
        main_ds_name = list(clean_datasets.keys())[0]
        main_df = clean_datasets[main_ds_name]

    # Metrics
    total_raw_rows = len(main_df) if main_df is not None else 0
    clean_rows = main_df[~main_df.get("_is_duplicate", False)] if main_df is not None and "_is_duplicate" in main_df.columns else main_df

    # 1. Revenue calculations
    total_col = None
    for c in ["Thanh_Tien", "Doanh_Thu", "total", "amount", "revenue"]:
        if main_df is not None and c in main_df.columns:
            total_col = c
            break

    raw_total_rev = 0.0
    adjusted_rev = 0.0
    outlier_rev = 0.0

    if main_df is not None and total_col:
        num_s = pd.to_numeric(main_df[total_col], errors="coerce").fillna(0)
        raw_total_rev = float(num_s.sum())

        # Exclude exact duplicates and outliers for adjusted revenue
        mask_valid = pd.Series(True, index=main_df.index)
        if "_is_duplicate" in main_df.columns:
            mask_valid &= (~main_df["_is_duplicate"])
        if "_is_outlier" in main_df.columns:
            mask_valid &= (~main_df["_is_outlier"])
            outlier_rev = float(num_s[main_df["_is_outlier"]].sum())

        adjusted_rev = float(num_s[mask_valid].sum())

    # -------------------------------------------------------------
    # Finding 1: Outliers distortion
    # -------------------------------------------------------------
    if main_df is not None and "_is_outlier" in main_df.columns and main_df["_is_outlier"].any():
        outlier_rows = main_df[main_df["_is_outlier"]]
        evidence = []
        for idx in outlier_rows.index[:5]:
            evidence.append({
                "dataset": main_ds_name,
                "row": int(idx) + 1,
                "col": total_col or "Outlier",
                "value": str(main_df.at[idx, total_col]) if total_col else "Outlier",
                "note": main_df.at[idx, "_outlier_reason"] if "_outlier_reason" in main_df.columns else "Vượt ngưỡng IQR"
            })
        findings.append({
            "id": f"{run_id}-FIND-{find_counter:03d}",
            "finding_code": f"FIND-{find_counter:03d}",
            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
            "title": f"Phát hiện {len(outlier_rows)} giao dịch ngoại lai làm méo mó doanh thu",
            "severity": "CRITICAL",
            "category": "ANOMALY",
            "description": f"Phát hiện các giá trị giao dịch đột biến bất thường (như đơn vị 999 sản phẩm hoặc giá trị gần 10 tỷ đồng), làm tổng doanh thu bị thổi phồng giả tạo từ {adjusted_rev:,.0f} đ lên {raw_total_rev:,.0f} đ.",
            "evidence_refs": evidence,
            "impact_estimate": f"Lệch số liệu: {outlier_rev:,.0f} đ (chiếm {(outlier_rev/max(raw_total_rev,1))*100:.1f}% tổng doanh thu thô)",
            "recommendation": "Tách riêng các giao dịch đột biến này ra khỏi báo cáo KPI thường nhật; yêu cầu bộ phận kiểm toán nội bộ xác minh đơn hàng bất thường.",
            "source": "RULE"
        })
        find_counter += 1

    # -------------------------------------------------------------
    # Finding 2: Logic calculation mismatch (Thành tiền != Qty * Price)
    # -------------------------------------------------------------
    if main_df is not None and "_is_logic_error" in main_df.columns and main_df["_is_logic_error"].any():
        logic_rows = main_df[main_df["_is_logic_error"]]
        evidence = []
        for idx in logic_rows.index[:5]:
            evidence.append({
                "dataset": main_ds_name,
                "row": int(idx) + 1,
                "col": total_col or "Logic",
                "value": str(main_df.at[idx, total_col]) if total_col else "",
                "note": main_df.at[idx, "_logic_error_details"] if "_logic_error_details" in main_df.columns else "Sai lệch công thức"
            })
        findings.append({
            "id": f"{run_id}-FIND-{find_counter:03d}",
            "finding_code": f"FIND-{find_counter:03d}",
            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
            "title": f"Phát hiện {len(logic_rows)} chứng từ sai lệch toán học giữa Thành tiền và Số lượng * Đơn giá",
            "severity": "HIGH",
            "category": "REVENUE_LEAKAGE",
            "description": f"Hệ thống phát hiện các dòng đơn hàng có Thành tiền không khớp với tích số của Số lượng và Đơn giá (vượt quá sai số cho phép 5%), có thể do nhân viên nhập tay đè số tiền hoặc lỗi phần mềm bán hàng.",
            "evidence_refs": evidence,
            "impact_estimate": "Nguy cơ thất thoát doanh thu hoặc tranh chấp công nợ với khách hàng",
            "recommendation": "Khoá trường Thành tiền trên phần mềm bán lẻ/ERP, bắt buộc tính tự động theo Số lượng * Đơn giá.",
            "source": "RULE"
        })
        find_counter += 1

    # -------------------------------------------------------------
    # Finding 3: Duplicates
    # -------------------------------------------------------------
    if main_df is not None and "_is_duplicate" in main_df.columns and main_df["_is_duplicate"].any():
        dup_rows = main_df[main_df["_is_duplicate"]]
        evidence = []
        for idx in dup_rows.index[:5]:
            evidence.append({
                "dataset": main_ds_name,
                "row": int(idx) + 1,
                "col": "Ma_Don_Hang" if "Ma_Don_Hang" in main_df.columns else "Row",
                "value": str(main_df.at[idx, "Ma_Don_Hang"]) if "Ma_Don_Hang" in main_df.columns else "",
                "note": main_df.at[idx, "_duplicate_note"] if "_duplicate_note" in main_df.columns else "Trùng lặp 100%"
            })
        findings.append({
            "id": f"{run_id}-FIND-{find_counter:03d}",
            "finding_code": f"FIND-{find_counter:03d}",
            "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
            "title": f"Phát hiện {len(dup_rows)} bản ghi đơn hàng trùng lặp chính xác",
            "severity": "HIGH",
            "category": "DATA_QUALITY",
            "description": "Các đơn hàng bị lặp lại nhiều lần do xuất file trùng kỳ hoặc lỗi đồng bộ dữ liệu hai chiều, dẫn đến khai khống doanh số.",
            "evidence_refs": evidence,
            "impact_estimate": "Doanh thu bị tính trùng lặp 2 lần",
            "recommendation": "Thiết lập ràng buộc Unique Key trên Mã đơn hàng trong cơ sở dữ liệu nguồn.",
            "source": "RULE"
        })
        find_counter += 1

    # -------------------------------------------------------------
    # Finding 4: Cross-file Debt Discrepancies (if debt file exists)
    # -------------------------------------------------------------
    debt_df = None
    for name, df in clean_datasets.items():
        if any(c in df.columns for c in ["Cong_No_Cuoi_Ky", "Han_Muc_Tin_Dung", "So_Ngay_Qua_Han"]):
            debt_df = df
            break

    if debt_df is not None:
        # Check credit limit violation
        if "Cong_No_Cuoi_Ky" in debt_df.columns and "Han_Muc_Tin_Dung" in debt_df.columns:
            over_limit = debt_df[debt_df["Cong_No_Cuoi_Ky"] > debt_df["Han_Muc_Tin_Dung"]]
            if not over_limit.empty:
                evidence = []
                for idx in over_limit.index:
                    evidence.append({
                        "dataset": "Sổ công nợ",
                        "row": int(idx) + 1,
                        "col": "Cong_No_Cuoi_Ky",
                        "value": f"{over_limit.at[idx, 'Cong_No_Cuoi_Ky']:,.0f} đ (Hạn mức: {over_limit.at[idx, 'Han_Muc_Tin_Dung']:,.0f} đ)",
                        "note": f"Đại lý {over_limit.at[idx, 'Ten_Dai_Ly'] if 'Ten_Dai_Ly' in over_limit.columns else idx} vượt trần tín dụng"
                    })
                findings.append({
                    "id": f"{run_id}-FIND-{find_counter:03d}",
                    "finding_code": f"FIND-{find_counter:03d}",
                    "run_id": run_id, "job_id": job_id, "workspace_id": workspace_id,
                    "title": f"Cảnh báo rủi ro tín dụng: {len(over_limit)} đại lý có công nợ vượt trần bảo lãnh",
                    "severity": "CRITICAL",
                    "category": "OPERATIONAL_RISK",
                    "description": "Đối soát chéo giữa Doanh thu và Sổ công nợ phát hiện đại lý đang nợ vượt hạn mức tín dụng được duyệt, tiềm ẩn nguy cơ nợ xấu và chiếm dụng vốn công ty.",
                    "evidence_refs": evidence,
                    "impact_estimate": "Nguy cơ nợ khó đòi lên tới hàng trăm triệu đồng",
                    "recommendation": "Tạm dừng xuất hàng công nợ cho các đại lý vượt trần; yêu cầu ký bổ sung bảo lãnh ngân hàng trước khi mở đơn mới.",
                    "source": "RULE"
                })
                find_counter += 1

    # -------------------------------------------------------------
    # Chart.js Data Preparation
    # -------------------------------------------------------------
    chart_data = {
        "region_sales": {"labels": [], "data": []},
        "quality_breakdown": {
            "labels": ["Dữ liệu sạch", "Trùng lặp", "Ngoại lai bất thường", "Lỗi toán học"],
            "data": [
                max(total_raw_rows - (len(findings) * 2), 0),
                sum(1 for f in findings if f["category"] == "DATA_QUALITY"),
                sum(1 for f in findings if f["category"] == "ANOMALY"),
                sum(1 for f in findings if f["category"] == "REVENUE_LEAKAGE")
            ]
        }
    }

    if main_df is not None and "Khu_Vuc" in main_df.columns and total_col:
        region_group = main_df.groupby("Khu_Vuc")[total_col].sum()
        chart_data["region_sales"]["labels"] = [str(k) for k in region_group.index]
        chart_data["region_sales"]["data"] = [float(round(v, 0)) for v in region_group.values]

    kpis = {
        "raw_total_rows": total_raw_rows,
        "clean_rows": len(clean_rows) if clean_rows is not None else 0,
        "raw_total_revenue": raw_total_rev,
        "adjusted_revenue": adjusted_rev,
        "outlier_distortion_amount": outlier_rev,
        "total_findings_count": len(findings),
        "critical_findings_count": sum(1 for f in findings if f["severity"] == "CRITICAL"),
        "high_findings_count": sum(1 for f in findings if f["severity"] == "HIGH")
    }

    return findings, kpis, chart_data


def generate_executive_report(
    problem_statement: str,
    business_context: Dict[str, Any],
    findings: List[Dict[str, Any]],
    kpis: Dict[str, Any],
    change_logs: List[Dict[str, Any]]
) -> Tuple[str, Dict[str, Any], str]:
    """
    Generates the executive strategic markdown report via Gemini (or deterministic fallback).
    Returns: (markdown_text, report_sections_dict, source_badge)
    """
    findings_summary = ""
    for f in findings:
        findings_summary += f"- [{f['id']}] ({f['severity']}) {f['title']}: {f['description']} (Tác động: {f['impact_estimate']})\n"

    prompt = f"""
BỐI CẢNH DOANH NGHIỆP:
- Ngành hàng: {business_context.get('industry', 'Sản xuất & Bán lẻ')}
- Vấn đề gặp phải: "{problem_statement}"

SỐ LIỆU ĐÃ TÍNH TOÁN XÁC ĐỊNH (BẮT BUỘC SỬ DỤNG, TUYỆT ĐỐI KHÔNG TỰ BỊA SỐ LIỆU):
- Tổng số dòng dữ liệu thô: {kpis.get('raw_total_rows', 0):,} dòng
- Doanh thu theo sổ sách ban đầu: {kpis.get('raw_total_revenue', 0):,.0f} đ
- Doanh thu thực tế sau khi làm sạch: {kpis.get('adjusted_revenue', 0):,.0f} đ
- Số tiền bị méo mó do ngoại lai & trùng lặp: {kpis.get('outlier_distortion_amount', 0):,.0f} đ
- Tổng số phát hiện trọng yếu: {kpis.get('total_findings_count', 0)} phát hiện ({kpis.get('critical_findings_count', 0)} nghiêm trọng)
- Tổng số thao tác làm sạch đã thực hiện: {len(change_logs):,} thao tác

DANH SÁCH PHÁT HIỆN KÈM BẰNG CHỨNG:
{findings_summary}

Hãy soạn Báo cáo Điều hành Chiến lược theo chuẩn cấu trúc Markdown 4 phần.
"""

    gemini_res = call_gemini(
        prompt=prompt,
        system_instruction=EXECUTIVE_REPORT_PROMPT,
        temperature=0.2,
        max_tokens=4000
    )

    if gemini_res.get("success") and gemini_res.get("text") and len(gemini_res["text"].strip()) > 100:
        md_text = gemini_res["text"].strip()
        sections = {
            "executive_summary": "Tóm lược điều hành đã được Gemini tổng hợp theo số liệu thực chứng.",
            "full_markdown": md_text
        }
        return md_text, sections, "GEMINI_AI"

    # Deterministic fallback report
    md_text = f"""# BÁO CÁO ĐIỀU HÀNH XỬ LÝ DỮ LIỆU & PHÂN TÍCH RỦI RO CHIẾN LƯỢC
> **Nguồn phân tích:** Hệ thống Phân tích Xác định DataIQ (Deterministic Rule-based Mode)  
> *Lưu ý: Phần diễn giải AI không khả dụng hoặc chưa cấu hình API Key. Toàn bộ nhận định dưới đây được xây dựng từ quy tắc logic và số liệu kiểm toán thực chứng.*

---

## 1. TÓM TẮT ĐIỀU HÀNH (EXECUTIVE SUMMARY)
Qua quá trình rà soát và làm sạch dữ liệu đối với bài toán **"{problem_statement}"**, hệ thống đã đối soát toàn diện **{kpis.get('raw_total_rows', 0):,}** bản ghi gốc.
- **Doanh thu ban đầu trên sổ sách:** **{kpis.get('raw_total_revenue', 0):,.0f} đ**
- **Doanh thu thực tế sau chuẩn hóa:** **{kpis.get('adjusted_revenue', 0):,.0f} đ**
- **Độ lệch sai số phát hiện:** **{kpis.get('outlier_distortion_amount', 0):,.0f} đ** bị thổi phồng bởi các giao dịch ngoại lai và trùng lặp đơn hàng.
- **Đã thực hiện:** **{len(change_logs):,}** thao tác hiệu chỉnh định dạng và xử lý dữ liệu thiếu trên Change Log.

---

## 2. PHÁT HIỆN TRỌNG TÂM & BẰNG CHỨNG XÁC THỰC
"""
    for f in findings:
        badge_color = "🔴" if f["severity"] == "CRITICAL" else ("🟠" if f["severity"] == "HIGH" else "🟡")
        md_text += f"""
### {badge_color} [{f['id']}] {f['title']}
- **Mức độ:** `{f['severity']}` | **Nhóm rủi ro:** `{f['category']}`
- **Bản chất vấn đề:** {f['description']}
- **Tác động ước tính:** **{f['impact_estimate']}**
- **Khuyến nghị xử lý:** {f['recommendation']}
"""

    md_text += f"""
---

## 3. PHÂN TÍCH NGUYÊN NHÂN GỐC RỄ (ROOT CAUSE ANALYSIS)
1. **Thiếu cơ chế kiểm soát hợp lệ dữ liệu tại điểm nhập (Data Entry Validation):** Cho phép nhập ngày không tồn tại (như 31/02), giá trị đơn hàng âm mà không có quy trình đối trừ rõ ràng.
2. **Không khóa tự động công thức tính Thành tiền:** Để nhân sự ghi đè số tiền dẫn đến mâu thuẫn giữa `Số lượng * Đơn giá` và `Thành tiền`.
3. **Cơ chế đồng bộ dữ liệu bị lặp bản ghi:** Chưa có ràng buộc Unique Key trên mã đơn hàng dẫn đến đơn hàng bị ghi nhận nhiều lần khi kết xuất báo cáo.

---

## 4. KHUYẾN NGHỊ HÀNH ĐỘNG CHIẾN LƯỢC
1. **Áp dụng bộ dữ liệu sạch đã xử lý:** Sử dụng tệp dữ liệu đã chuẩn hóa xuất từ DataIQ để lập báo cáo tài chính chính thức kỳ này.
2. **Rà soát hạn mức tín dụng đại lý:** Thu hồi ngay công nợ các đại lý vượt trần hoặc quá hạn thanh toán trên 30 ngày.
3. **Chuẩn hóa phần mềm quản lý kho & bán hàng:** Ràng buộc tự động tính toán số tiền và ngăn chặn đơn hàng trùng lặp.
"""
    sections = {
        "executive_summary": "Báo cáo điều hành tự động theo luật xác định.",
        "full_markdown": md_text
    }
    return md_text, sections, "DETERMINISTIC_FALLBACK"
