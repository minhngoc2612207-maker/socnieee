"""
Scoring Engine module:
Calculates 100-point rubric across Commercial, Warranty, Financial, and Location categories.
Applies dynamic updates from verified field data and triggers the Phantom Commitment Penalty (-25 pts & Red Flag).
"""

from typing import Dict, Any, List, Tuple, Optional


def calculate_dossier_score(
    intake_data: Dict[str, Any],
    compliance_res: Optional[Dict[str, Any]] = None,
    verification_tickets: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Computes category breakdown, total score, penalties, red flags, and tier classification.
    """
    legal = intake_data.get("legal_entity", {})
    location = intake_data.get("location_logistics", {})
    commercial = intake_data.get("commercial_commitment", {})
    technical = intake_data.get("technical_service", {})
    financial = intake_data.get("financial_credit", {})

    # Extract verified values if available from Step 3
    verified_techs = technical.get("technician_count", 0)
    verified_area = technical.get("workshop_area_m2", 0.0)
    effective_revenue = commercial.get("committed_monthly_revenue", 0)
    effective_cic = "Nhóm 1 - Nợ đủ tiêu chuẩn"

    if verification_tickets and "tickets" in verification_tickets:
        tickets = verification_tickets["tickets"]
        # Operations findings
        ops_findings = tickets.get("operations", {}).get("findings", {})
        if "verified_technicians" in ops_findings:
            verified_techs = int(ops_findings["verified_technicians"])
        if "verified_workshop_area" in ops_findings:
            verified_area = float(ops_findings["verified_workshop_area"])

        # Sales findings
        sales_findings = tickets.get("sales", {}).get("findings", {})
        if "verified_monthly_revenue" in sales_findings and sales_findings["verified_monthly_revenue"]:
            effective_revenue = int(sales_findings["verified_monthly_revenue"])

        # Finance findings
        fin_findings = tickets.get("finance", {}).get("findings", {})
        if "cic_group" in fin_findings:
            effective_cic = fin_findings["cic_group"]

    # ---------------------------------------------------------
    # 1. THƯƠNG MẠI & BÁN HÀNG (Max 30đ)
    # ---------------------------------------------------------
    comm_score = 0
    comm_details = []

    # Revenue scale (Max 15đ)
    if effective_revenue >= 1500000000:
        comm_score += 15
        comm_details.append(f"Doanh số cam kết rất cao ({effective_revenue:,} VNĐ): +15/15đ")
    elif effective_revenue >= 800000000:
        comm_score += 12
        comm_details.append(f"Doanh số cam kết khá tốt ({effective_revenue:,} VNĐ): +12/15đ")
    elif effective_revenue >= 300000000:
        comm_score += 8
        comm_details.append(f"Doanh số cam kết trung bình ({effective_revenue:,} VNĐ): +8/15đ")
    else:
        comm_score += 4
        comm_details.append(f"Doanh số cam kết thấp ({effective_revenue:,} VNĐ): +4/15đ")

    # Channels & Network (Max 10đ)
    channels = commercial.get("target_channels", [])
    if isinstance(channels, list) and len(channels) >= 2:
        comm_score += 10
        comm_details.append("Đa dạng kênh bán buôn & dự án công trình: +10/10đ")
    elif channels:
        comm_score += 7
        comm_details.append("Có kênh bán buôn cơ bản: +7/10đ")
    else:
        comm_score += 4
        comm_details.append("Kênh bán hàng hẹp: +4/10đ")

    # Industry experience (Max 5đ)
    exp_years = commercial.get("industry_experience_years", 0)
    if exp_years >= 5:
        comm_score += 5
        comm_details.append(f"Kinh nghiệm ngành gia dụng dày dạn ({exp_years} năm): +5/5đ")
    elif exp_years >= 2:
        comm_score += 3
        comm_details.append(f"Kinh nghiệm ngành gia dụng ({exp_years} năm): +3/5đ")
    else:
        comm_score += 1
        comm_details.append("Kinh nghiệm mới dưới 2 năm: +1/5đ")

    comm_score = min(30, comm_score)

    # ---------------------------------------------------------
    # 2. BẢO HÀNH & KỸ THUẬT (Max 25đ) - TIÊU CHÍ TRỌNG YẾU
    # ---------------------------------------------------------
    warr_score = 0
    warr_details = []

    # Headcount (Max 10đ)
    if verified_techs >= 3:
        warr_score += 10
        warr_details.append(f"Đội ngũ kỹ thuật mạnh ({verified_techs} thợ cơ hữu): +10/10đ")
    elif verified_techs == 2:
        warr_score += 7
        warr_details.append(f"Đạt chuẩn tối thiểu ({verified_techs} thợ cơ hữu): +7/10đ")
    elif verified_techs == 1:
        warr_score += 3
        warr_details.append("Chỉ có 1 thợ, thiếu nhân lực dự phòng: +3/10đ")
    else:
        warr_score += 0
        warr_details.append("0 thợ kỹ thuật cơ hữu (Rất nguy hiểm): +0/10đ")

    # Workshop area (Max 7đ)
    if verified_area >= 30:
        warr_score += 7
        warr_details.append(f"Xưởng sửa chữa rộng rãi ({verified_area} m²): +7/7đ")
    elif verified_area >= 15:
        warr_score += 5
        warr_details.append(f"Đạt chuẩn diện tích trạm dịch vụ ({verified_area} m²): +5/7đ")
    elif verified_area > 0:
        warr_score += 2
        warr_details.append(f"Diện tích xưởng dưới chuẩn ({verified_area} m² < 15 m²): +2/7đ")
    else:
        warr_score += 0
        warr_details.append("Không có khu vực xưởng kỹ thuật: +0/7đ")

    # SLA commitment (Max 5đ)
    sla_hours = technical.get("sla_commit_hours", 48)
    if sla_hours <= 24:
        warr_score += 5
        warr_details.append(f"Cam kết xử lý sự cố thần tốc (SLA {sla_hours}h): +5/5đ")
    elif sla_hours <= 48:
        warr_score += 4
        warr_details.append(f"Cam kết SLA đạt chuẩn hãng ({sla_hours}h): +4/5đ")
    else:
        warr_score += 1
        warr_details.append(f"Cam kết SLA chậm ({sla_hours}h > 48h): +1/5đ")

    # Spare parts readiness (Max 3đ)
    if technical.get("spare_parts_stock", False):
        warr_score += 3
        warr_details.append("Có giá kệ tồn trữ linh kiện thay thế: +3/3đ")
    else:
        warr_details.append("Chưa có kho linh kiện dự phòng: +0/3đ")

    warr_score = min(25, warr_score)

    # ---------------------------------------------------------
    # 3. TÀI CHÍNH & PHÁP LÝ (Max 25đ)
    # ---------------------------------------------------------
    fin_score = 0
    fin_details = []

    # CIC status (Max 10đ)
    if "Nhóm 1" in effective_cic:
        fin_score += 10
        fin_details.append(f"Lịch sử tín dụng CIC sạch ({effective_cic}): +10/10đ")
    elif "Nhóm 2" in effective_cic:
        fin_score += 4
        fin_details.append(f"CIC Nhóm 2 (Cần theo dõi): +4/10đ")
    else:
        fin_score += 0
        fin_details.append(f"CIC nợ xấu ({effective_cic}): +0/10đ")

    # Credit policy compliance (Max 10đ)
    req_debt_days = financial.get("requested_debt_days", 30)
    req_credit = financial.get("requested_credit_limit", 0)
    has_bg = financial.get("has_bank_guarantee", False)

    if req_debt_days <= 30 and (req_credit <= 500000000 or has_bg):
        fin_score += 10
        fin_details.append(f"Tuyệt đối tuân thủ chính sách nợ (<=30 ngày, có bảo lãnh nếu >500M): +10/10đ")
    elif req_debt_days <= 45 and (req_credit <= 500000000 or has_bg):
        fin_score += 6
        fin_details.append(f"Thời hạn nợ {req_debt_days} ngày trong ngưỡng đàm phán: +6/10đ")
    else:
        fin_score += 0
        fin_details.append(f"Vi phạm trần công nợ ({req_debt_days} ngày / {req_credit:,} VNĐ): +0/10đ")

    # Charter capital & stability (Max 5đ)
    capital = financial.get("charter_capital", 0)
    if capital >= 5000000000:
        fin_score += 5
        fin_details.append(f"Vốn điều lệ vững mạnh ({capital:,} VNĐ): +5/5đ")
    elif capital >= 2000000000:
        fin_score += 3
        fin_details.append(f"Vốn điều lệ khá ({capital:,} VNĐ): +3/5đ")
    else:
        fin_score += 1
        fin_details.append("Vốn điều lệ mỏng (<2 tỷ): +1/5đ")

    fin_score = min(25, fin_score)

    # ---------------------------------------------------------
    # 4. VỊ TRÍ & KHO BÃI (Max 20đ)
    # ---------------------------------------------------------
    loc_score = 0
    loc_details = []

    # Storefront width (Max 8đ)
    front_m = location.get("store_front_width_m", 0)
    if front_m >= 10:
        loc_score += 8
        loc_details.append(f"Mặt tiền xuất sắc ({front_m}m >= 10m): +8/8đ")
    elif front_m >= 6:
        loc_score += 6
        loc_details.append(f"Mặt tiền đạt chuẩn ({front_m}m): +6/8đ")
    else:
        loc_score += 3
        loc_details.append(f"Mặt tiền nhỏ hẹp ({front_m}m): +3/8đ")

    # Warehouse area (Max 7đ)
    wh_m2 = location.get("warehouse_area_m2", 0)
    if wh_m2 >= 150:
        loc_score += 7
        loc_details.append(f"Kho chứa hàng quy mô ({wh_m2} m²): +7/7đ")
    elif wh_m2 >= 80:
        loc_score += 5
        loc_details.append(f"Kho hàng đạt yêu cầu ({wh_m2} m²): +5/7đ")
    else:
        loc_score += 2
        loc_details.append(f"Kho hàng nhỏ ({wh_m2} m² < 80 m²): +2/7đ")

    # Truck accessibility (Max 5đ)
    if location.get("truck_accessible", False):
        loc_score += 5
        loc_details.append("Đường lớn, xe tải bốc dỡ hàng hóa thuận tiện: +5/5đ")
    else:
        loc_score += 1
        loc_details.append("Giao thông khó khăn cho xe tải: +1/5đ")

    loc_score = min(20, loc_score)

    raw_total = comm_score + warr_score + fin_score + loc_score

    # ---------------------------------------------------------
    # 5. QUY TẮC PHẠT BẪY CAM KẾT ẢO (PHANTOM COMMITMENT RULE)
    # ---------------------------------------------------------
    is_phantom = False
    phantom_penalty = 0
    phantom_reasons = []

    # Condition: High Revenue Commitment (>= 1.5 tỷ) BUT Low Warranty Capability (< 12 pts) OR 0 Techs OR Extreme Debt (> 45 days)
    if effective_revenue >= 1500000000:
        if warr_score < 12 or verified_techs == 0 or req_debt_days > 45:
            is_phantom = True
            phantom_penalty = 25
            if verified_techs == 0:
                phantom_reasons.append("Khai báo 0 thợ kỹ thuật cơ hữu để tiếp nhận xử lý sự cố thiết bị gia dụng")
            if warr_score < 12:
                phantom_reasons.append(f"Năng lực dịch vụ bảo hành quá yếu ({warr_score}/25 điểm), không đạt chuẩn trạm ủy quyền")
            if req_debt_days > 45:
                phantom_reasons.append(f"Đòi nợ gối đầu bất thường ({req_debt_days} ngày > 45 ngày)")

    # Deduct Compliance Violations if critical
    compliance_penalties = 0
    compliance_penalty_details = []
    if compliance_res:
        for v in compliance_res.get("violations", []):
            if v.get("code") == "BLACK_LIST_BAD_DEBT":
                compliance_penalties += 40
                compliance_penalty_details.append("Phạt Nợ xấu / Blacklist: -40đ")
            elif v.get("code") == "GEOFENCE_RADIUS_BREACH":
                compliance_penalties += 15
                compliance_penalty_details.append("Phạt Vi phạm Bán kính bảo hộ: -15đ")
            elif v.get("code") == "EXCLUSIVE_DISTRICT_COLLISION":
                compliance_penalties += 15
                compliance_penalty_details.append("Phạt Xung đột quận độc quyền: -15đ")
            elif v.get("code") == "DEBT_DAYS_CEILING_EXCEEDED":
                compliance_penalties += 10
                compliance_penalty_details.append("Phạt Vượt trần cấm công nợ: -10đ")

    total_penalty = phantom_penalty + compliance_penalties
    final_score = max(0, min(100, raw_total - total_penalty))

    # ---------------------------------------------------------
    # 6. PHÂN HẠNG TIER
    # ---------------------------------------------------------
    if is_phantom or (compliance_res and compliance_res.get("status") == "CRITICAL_FAIL") or final_score < 50:
        tier = "Tier D"
        tier_title = "Từ chối / Chưa tiếp tục"
        tier_action = "Chưa tiếp tục xem xét hoặc từ chối do vi phạm quy chuẩn an toàn của Tập đoàn."
        badge_color = "red"
    elif final_score >= 80:
        tier = "Tier A"
        tier_title = "Hợp tác ngay"
        tier_action = "Đối tác xuất sắc, đáp ứng đầy đủ tiêu chí. Mời ký hợp đồng phân phối chính thức."
        badge_color = "green"
    elif final_score >= 65:
        tier = "Tier B"
        tier_title = "Đàm phán có điều kiện"
        tier_action = "Năng lực tốt nhưng cần siết công nợ, yêu cầu bổ sung bảo lãnh ngân hàng hoặc tuyển thêm KTV trước khi kích hoạt mã đại lý."
        badge_color = "blue"
    else:
        tier = "Tier C"
        tier_title = "Xem xét hạn chế"
        tier_action = "Chỉ áp dụng cơ chế mua đứt bán đoạn không công nợ hoặc làm đại lý bán lẻ vệ tinh."
        badge_color = "amber"

    return {
        "final_score": final_score,
        "raw_total_score": raw_total,
        "total_penalty": total_penalty,
        "tier": tier,
        "tier_title": tier_title,
        "tier_action": tier_action,
        "badge_color": badge_color,
        "is_phantom_commitment": is_phantom,
        "phantom_flag": "RED_FLAG_PHANTOM_COMMITMENT" if is_phantom else None,
        "phantom_penalty": phantom_penalty,
        "phantom_reasons": phantom_reasons,
        "categories": {
            "commercial": {
                "score": comm_score,
                "max": 30,
                "percentage": round(comm_score / 30 * 100, 1),
                "details": comm_details
            },
            "warranty_technical": {
                "score": warr_score,
                "max": 25,
                "percentage": round(warr_score / 25 * 100, 1),
                "details": warr_details
            },
            "financial_legal": {
                "score": fin_score,
                "max": 25,
                "percentage": round(fin_score / 25 * 100, 1),
                "details": fin_details
            },
            "location_logistics": {
                "score": loc_score,
                "max": 20,
                "percentage": round(loc_score / 20 * 100, 1),
                "details": loc_details
            }
        },
        "compliance_penalty_details": compliance_penalty_details
    }
