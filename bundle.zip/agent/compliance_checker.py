"""
Compliance Checker module:
Performs Identity Duplicate & Blacklist scanning,
Haversine Geofencing radius & exclusive district analysis,
and Credit Policy Ceiling verification.
"""

import os
import json
import math
from typing import Dict, Any, List, Optional, Tuple

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
PARTNERS_FILE = os.path.join(DATA_DIR, "existing_partners.json")
POLICIES_FILE = os.path.join(DATA_DIR, "policies.json")


def load_json_file(file_path: str) -> Dict[str, Any]:
    """Safely loads a JSON file."""
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def haversine_distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Calculates great-circle distance between two GPS coordinates using Haversine formula.
    Returns distance in kilometers.
    """
    R = 6371.0  # Earth's radius in km

    d_lat = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)

    a = (math.sin(d_lat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(d_lon / 2) ** 2)
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    return round(R * c, 2)


def run_compliance_check(intake_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Executes full Step 2 Compliance & Risk Screening on applicant intake data.
    """
    partners_db = load_json_file(PARTNERS_FILE)
    policies = load_json_file(POLICIES_FILE)

    active_partners = partners_db.get("active_partners", [])
    blacklisted_entities = partners_db.get("blacklisted_entities", [])

    credit_policy = policies.get("credit_policy", {})
    geofence_policy = policies.get("geofencing", {})

    legal = intake_data.get("legal_entity", {})
    location = intake_data.get("location_logistics", {})
    financial = intake_data.get("financial_credit", {})

    applicant_mst = (legal.get("tax_id") or "").strip().replace(" ", "").replace("-", "")
    applicant_phone = (legal.get("phone") or "").strip().replace(" ", "").replace(".", "")
    applicant_rep = (legal.get("legal_rep") or "").strip().lower()
    applicant_name = (legal.get("company_name") or "").strip().lower()

    applicant_lat = float(location.get("latitude") or 0.0)
    applicant_lon = float(location.get("longitude") or 0.0)
    applicant_district = (location.get("district") or "").strip()
    applicant_province = (location.get("province") or "").strip()

    req_debt_days = int(financial.get("requested_debt_days") or 0)
    req_credit_limit = int(financial.get("requested_credit_limit") or 0)
    has_bank_guarantee = bool(financial.get("has_bank_guarantee", False))

    violations: List[Dict[str, Any]] = []
    warnings: List[Dict[str, Any]] = []
    checks: List[Dict[str, Any]] = []

    # -------------------------------------------------------------
    # 1. Quét Blacklist Nợ Xấu & Gian Lận
    # -------------------------------------------------------------
    blacklist_hit = None
    for b_item in blacklisted_entities:
        b_mst = b_item.get("tax_id", "").replace(" ", "").replace("-", "")
        b_phone = b_item.get("phone", "").replace(" ", "").replace(".", "")
        b_rep = b_item.get("legal_rep", "").lower()

        is_match = False
        match_reason = ""
        if applicant_mst and b_mst and (applicant_mst == b_mst):
            is_match = True
            match_reason = f"Trùng khớp 100% Mã số thuế ({b_item.get('tax_id')})"
        elif applicant_phone and b_phone and (applicant_phone == b_phone):
            is_match = True
            match_reason = f"Trùng khớp Số điện thoại liên hệ ({b_item.get('phone')})"
        elif applicant_rep and b_rep and (applicant_rep == b_rep):
            is_match = True
            match_reason = f"Trùng khớp Họ tên Người đại diện pháp luật ({b_item.get('legal_rep')})"

        if is_match:
            blacklist_hit = {
                "matched_company": b_item.get("company_name"),
                "tax_id": b_item.get("tax_id"),
                "legal_rep": b_item.get("legal_rep"),
                "match_reason": match_reason,
                "bad_debt_amount_vnd": b_item.get("bad_debt_amount_vnd", 0),
                "reason": b_item.get("reason"),
                "cic_classification": b_item.get("cic_classification"),
                "legal_action": b_item.get("legal_action")
            }
            violations.append({
                "code": "BLACK_LIST_BAD_DEBT",
                "severity": "CRITICAL",
                "title": "CẢNH BÁO ĐỎ: Phát hiện Nợ Xấu / Gian Lận trong Blacklist",
                "detail": f"{match_reason} với đối tác '{b_item.get('company_name')}'. Đang nợ xấu {b_item.get('bad_debt_amount_vnd', 0):,} VNĐ ({b_item.get('cic_classification')}). Lý do: {b_item.get('reason')}."
            })
            break

    checks.append({
        "name": "Đối soát Danh sách Nợ xấu (Blacklist)",
        "status": "FAIL" if blacklist_hit else "PASS",
        "description": "Quét MST, SĐT, Người đại diện với cơ sở dữ liệu đối tác từng vi phạm hợp đồng và nợ xấu của Đại Thành",
        "result_text": f"PHÁT HIỆN TRÙNG LẶP BLACKLIST: {blacklist_hit['matched_company']}" if blacklist_hit else "Dữ liệu pháp nhân sạch, không có lịch sử nợ xấu tại Đại Thành"
    })

    # -------------------------------------------------------------
    # 2. Quét Trùng lặp Đại lý Hiện hữu (Đổi tên pháp nhân để lách chính sách)
    # -------------------------------------------------------------
    duplicate_partner_hit = None
    if not blacklist_hit:
        for p in active_partners:
            p_mst = p.get("tax_id", "").replace(" ", "").replace("-", "")
            p_phone = p.get("phone", "").replace(" ", "").replace(".", "")
            p_rep = p.get("legal_rep", "").lower()

            if applicant_mst and p_mst and (applicant_mst == p_mst):
                duplicate_partner_hit = p
                violations.append({
                    "code": "DUPLICATE_ACTIVE_PARTNER_MST",
                    "severity": "CRITICAL",
                    "title": "Trùng lặp Mã số thuế Đại lý hiện hữu",
                    "detail": f"MST {applicant_mst} đã thuộc về đại lý đang hoạt động '{p.get('company_name')}' ({p.get('tier')}, {p.get('region')}). Có dấu hiệu đăng ký lại để nhận ưu đãi tân đại lý."
                })
                break
            elif applicant_phone and p_phone and (applicant_phone == p_phone):
                warnings.append({
                    "code": "DUPLICATE_PHONE_WARNING",
                    "severity": "MEDIUM",
                    "title": "Số điện thoại trùng với đại lý đang hoạt động",
                    "detail": f"SĐT {applicant_phone} trùng với đại lý '{p.get('company_name')}'. Cần xác minh tính độc lập của pháp nhân mới."
                })
                break

    checks.append({
        "name": "Quét Trùng Lặp Danh Tính Đối Tác Hiện Hữu",
        "status": "FAIL" if duplicate_partner_hit else ("WARNING" if any(w["code"] == "DUPLICATE_PHONE_WARNING" for w in warnings) else "PASS"),
        "description": "Phát hiện đại lý cũ đổi tên pháp nhân hoặc thành lập công ty con để hưởng chính sách ưu đãi mở mới",
        "result_text": f"Trùng lặp với {duplicate_partner_hit['company_name']}" if duplicate_partner_hit else "Không phát hiện trùng lặp MST với hệ thống đại lý hiện hữu"
    })

    # -------------------------------------------------------------
    # 3. Geofencing Địa bàn & Bán kính Bảo hộ (Haversine Formula)
    # -------------------------------------------------------------
    partner_distances: List[Dict[str, Any]] = []
    min_radius_limit = geofence_policy.get("min_protection_radius_km", 3.5)
    tier1_radius_limit = geofence_policy.get("tier1_protection_radius_km", 4.0)

    exclusive_district_conflict = None
    radius_violation_partner = None

    if applicant_lat != 0.0 and applicant_lon != 0.0:
        for p in active_partners:
            p_lat = float(p.get("latitude", 0.0))
            p_lon = float(p.get("longitude", 0.0))
            if p_lat != 0.0 and p_lon != 0.0:
                dist = haversine_distance_km(applicant_lat, applicant_lon, p_lat, p_lon)
                prot_radius = float(p.get("protection_radius_km", min_radius_limit))
                is_conflict = dist < prot_radius

                item = {
                    "partner_id": p.get("id"),
                    "company_name": p.get("company_name"),
                    "tier": p.get("tier"),
                    "region": p.get("region"),
                    "address": p.get("address"),
                    "exclusive_district": p.get("exclusive_district"),
                    "distance_km": dist,
                    "protection_radius_km": prot_radius,
                    "is_radius_conflict": is_conflict
                }
                partner_distances.append(item)

                if is_conflict and not radius_violation_partner:
                    radius_violation_partner = item

                # Check exclusive district conflict
                p_dist_name = (p.get("exclusive_district") or "").lower()
                if p_dist_name and applicant_district and (p_dist_name in applicant_district.lower() or applicant_district.lower() in p_dist_name):
                    exclusive_district_conflict = p

        partner_distances.sort(key=lambda x: x["distance_km"])
    else:
        warnings.append({
            "code": "MISSING_GPS",
            "severity": "LOW",
            "title": "Thiếu tọa độ GPS chính xác",
            "detail": "Hồ sơ chưa có tọa độ vĩ độ/kinh độ chính xác, cần Phòng Kinh doanh khảo sát thực địa để chốt Geofencing."
        })

    nearest_partner = partner_distances[0] if partner_distances else None

    # Handle radius conflict violation
    if radius_violation_partner:
        violations.append({
            "code": "GEOFENCE_RADIUS_BREACH",
            "severity": "HIGH",
            "title": f"Vi phạm Bán kính Bảo hộ Địa bàn ({radius_violation_partner['distance_km']} km)",
            "detail": f"Điểm bán mới chỉ cách đại lý '{radius_violation_partner['company_name']}' {radius_violation_partner['distance_km']} km, vi phạm bán kính bảo hộ tối thiểu {radius_violation_partner['protection_radius_km']} km theo quy định của Đại Thành."
        })

    # Handle exclusive district conflict
    if exclusive_district_conflict:
        violations.append({
            "code": "EXCLUSIVE_DISTRICT_COLLISION",
            "severity": "HIGH",
            "title": f"Xung đột Quận Độc Quyền ({applicant_district})",
            "detail": f"Điểm bán nằm trong địa bàn bảo hộ độc quyền '{exclusive_district_conflict.get('exclusive_district')}' của Đại lý Cấp 1 '{exclusive_district_conflict.get('company_name')}'."
        })

    geofence_status = "FAIL" if (radius_violation_partner or exclusive_district_conflict) else ("WARNING" if not partner_distances else "PASS")
    checks.append({
        "name": "Bảo hộ Địa bàn & Geofencing (Bán kính 3.5 - 4.0 km)",
        "status": geofence_status,
        "description": "Tính toán khoảng cách Haversine và đối soát danh mục quận/huyện độc quyền của Đại lý Cấp 1",
        "result_text": (
            f"VI PHẠM: Cách '{radius_violation_partner['company_name']}' {radius_violation_partner['distance_km']} km (< {radius_violation_partner['protection_radius_km']} km)"
            if radius_violation_partner else
            (f"XUNG ĐỘT: Trùng quận độc quyền '{exclusive_district_conflict.get('exclusive_district')}'"
             if exclusive_district_conflict else
             f"HỢP LỆ: Đại lý gần nhất '{nearest_partner['company_name']}' cách {nearest_partner['distance_km']} km (An toàn > 3.5km)" if nearest_partner else "Chưa có GPS")
        )
    })

    # -------------------------------------------------------------
    # 4. Soát Trần Chính sách Công nợ & Tín chấp
    # -------------------------------------------------------------
    forbidden_debt_ceiling = credit_policy.get("forbidden_debt_days_ceiling", 45)
    max_debt_standard = credit_policy.get("max_debt_days_standard", 30)
    max_unsecured = credit_policy.get("max_unsecured_credit_limit_vnd", 500000000)

    # Debt days check
    if req_debt_days > forbidden_debt_ceiling:
        violations.append({
            "code": "DEBT_DAYS_CEILING_EXCEEDED",
            "severity": "CRITICAL",
            "title": f"Vi phạm Trần Cấm Công Nợ ({req_debt_days} ngày)",
            "detail": f"Đề xuất nợ gối đầu {req_debt_days} ngày vượt qua Trần cấm tối đa của Tập đoàn ({forbidden_debt_ceiling} ngày). Tiêu chuẩn áp dụng không quá {max_debt_standard} ngày."
        })
    elif req_debt_days > max_debt_standard:
        warnings.append({
            "code": "DEBT_DAYS_OVER_STANDARD",
            "severity": "MEDIUM",
            "title": f"Thời hạn nợ vượt khung chuẩn ({req_debt_days} ngày)",
            "detail": f"Đề xuất nợ {req_debt_days} ngày vượt khung chuẩn ({max_debt_standard} ngày). Cần bảo lãnh ngân hàng hoặc ý kiến Trưởng phòng PTKD."
        })

    # Unsecured credit ceiling check
    if req_credit_limit > max_unsecured and not has_bank_guarantee:
        violations.append({
            "code": "UNSECURED_CREDIT_EXCEEDED",
            "severity": "HIGH",
            "title": f"Vượt Trần Tín Chấp Không Bảo Lãnh ({req_credit_limit:,} VNĐ)",
            "detail": f"Đề xuất hạn mức {req_credit_limit:,} VNĐ vượt trần tín chấp cho phép ({max_unsecured:,} VNĐ) nhưng KHÔNG có Thư bảo lãnh ngân hàng kèm theo."
        })
    elif req_credit_limit > max_unsecured and has_bank_guarantee:
        # Compliant because bank guarantee is present
        pass

    credit_status = "FAIL" if any(v["code"] in ["DEBT_DAYS_CEILING_EXCEEDED", "UNSECURED_CREDIT_EXCEEDED"] for v in violations) else ("WARNING" if any(w["code"] == "DEBT_DAYS_OVER_STANDARD" for w in warnings) else "PASS")
    checks.append({
        "name": "Kiểm Soát Trần Công Nợ & Bảo Lãnh Ngân Hàng",
        "status": credit_status,
        "description": f"Chính sách nợ tối đa {max_debt_standard} ngày (trần cấm >{forbidden_debt_ceiling} ngày), hạn mức tín chấp tối đa {max_unsecured:,} VNĐ",
        "result_text": (
            f"KHÔNG ĐẠT: Nợ {req_debt_days} ngày / Hạn mức {req_credit_limit:,} VNĐ (Không bảo lãnh)"
            if credit_status == "FAIL" else
            (f"CẦN ĐÀM PHÁN: Nợ {req_debt_days} ngày vượt chuẩn {max_debt_standard} ngày" if credit_status == "WARNING" else
             f"HỢP LỆ: Nợ {req_debt_days} ngày, hạn mức {req_credit_limit:,} VNĐ ({'Có bảo lãnh NH' if has_bank_guarantee else 'Trong hạn mức tín chấp'})")
        )
    })

    # Overall Status
    if any(v["severity"] == "CRITICAL" for v in violations):
        overall_status = "CRITICAL_FAIL"
        summary = "Hồ sơ vi phạm nghiêm trọng chính sách cốt lõi của Đại Thành (Nợ xấu / Trùng lặp pháp nhân / Vượt trần cấm công nợ). Không thể kích hoạt ký hợp đồng."
    elif violations:
        overall_status = "WARNING"
        summary = f"Phát hiện {len(violations)} điểm xung đột hoặc vi phạm chính sách địa bàn/công nợ. Cần bước xác minh thực địa và đàm phán điều kiện khắt khe."
    elif warnings:
        overall_status = "WARNING"
        summary = f"Hồ sơ cơ bản tuân thủ nhưng có {len(warnings)} điểm cần lưu ý và thẩm định chuyên sâu trước khi ký hợp đồng."
    else:
        overall_status = "PASS"
        summary = "Hồ sơ hoàn toàn sạch về pháp lý, an toàn tuyệt đối về địa bàn bảo hộ và tuân thủ chặt chẽ khung chính sách công nợ của Đại Thành."

    return {
        "status": overall_status,
        "summary": summary,
        "violations": violations,
        "warnings": warnings,
        "checks": checks,
        "nearest_partner": nearest_partner,
        "partner_distances": partner_distances[:5],
        "blacklist_hit": blacklist_hit,
        "duplicate_partner_hit": duplicate_partner_hit,
        "radius_violation_partner": radius_violation_partner,
        "exclusive_district_conflict": exclusive_district_conflict
    }

