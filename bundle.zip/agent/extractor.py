"""
Extractor module: Handles document reading (.pdf, .docx, .txt),
form data normalization, and intelligent extraction via Gemini LLM or heuristic fallback.
"""

import os
import re
import json
from typing import Dict, Any, Tuple
import pypdf
import docx

from agent.llm_client import call_gemini


def extract_text_from_file(file_path: str) -> str:
    """Reads raw text from PDF, DOCX, or TXT file."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Tệp không tồn tại: {file_path}")

    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        text_parts = []
        with open(file_path, "rb") as f:
            reader = pypdf.PdfReader(f)
            for page in reader.pages:
                t = page.extract_text()
                if t:
                    text_parts.append(t)
        return "\n".join(text_parts)

    elif ext in [".docx", ".doc"]:
        doc = docx.Document(file_path)
        text_parts = []
        for p in doc.paragraphs:
            if p.text.strip():
                text_parts.append(p.text.strip())
        for table in doc.tables:
            for row in table.rows:
                row_text = " | ".join([cell.text.strip() for cell in row.cells if cell.text.strip()])
                if row_text:
                    text_parts.append(row_text)
        return "\n".join(text_parts)

    elif ext in [".txt", ".json", ".csv"]:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    else:
        raise ValueError(f"Định dạng tệp không được hỗ trợ: {ext}. Vui lòng dùng .pdf, .docx hoặc .txt")


EXTRACTION_SYSTEM_PROMPT = """
Bạn là Trợ lý AI Chuyên gia Bóc tách Hồ sơ Đối tác Phân phối cho Công ty Cổ phần Thiết bị Gia dụng Đại Thành.
Nhiệm vụ của bạn là đọc kỹ văn bản hồ sơ đăng ký đại lý và bóc tách thành một đối tượng JSON chuẩn xác theo đúng cấu trúc sau (chỉ trả về JSON thuần túy, không có văn bản giải thích phụ):

{
  "legal_entity": {
    "company_name": "Tên pháp nhân đầy đủ",
    "tax_id": "Mã số thuế",
    "legal_rep": "Họ tên người đại diện pháp luật",
    "phone": "Số điện thoại liên hệ",
    "email": "Email liên hệ",
    "established_year": 2020,
    "region": "KV1" hoặc "KV2" hoặc "KV3"
  },
  "location_logistics": {
    "address": "Địa chỉ điểm bán / kho",
    "district": "Quận / Huyện",
    "province": "Tỉnh / Thành phố",
    "latitude": 21.0312,
    "longitude": 105.7950,
    "store_front_width_m": 8.5,
    "warehouse_area_m2": 120.0,
    "truck_accessible": true
  },
  "commercial_commitment": {
    "committed_monthly_revenue": 1500000000,
    "product_lines": ["Bếp từ", "Máy lọc nước", "Bình nước nóng"],
    "target_channels": ["Đại lý cấp 2", "Dự án", "Bán lẻ"],
    "industry_experience_years": 5
  },
  "technical_service": {
    "technician_count": 2,
    "workshop_area_m2": 25.0,
    "sla_commit_hours": 48,
    "spare_parts_stock": true
  },
  "financial_credit": {
    "requested_credit_limit": 500000000,
    "requested_debt_days": 30,
    "has_bank_guarantee": false,
    "charter_capital": 3000000000
  }
}
Lưu ý quy đổi:
- KV1: Miền Bắc (Hà Nội, Hải Phòng, Quảng Ninh, Phú Thọ, Bắc Ninh, ...)
- KV2: Miền Trung (Đà Nẵng, Nghệ An, Huế, Quảng Nam, Khánh Hòa, ...)
- KV3: Miền Nam (TP.HCM, Bình Dương, Đồng Nai, Long An, Cần Thơ, ...)
- committed_monthly_revenue, requested_credit_limit, charter_capital tính bằng VNĐ dạng số nguyên.
- Số thợ (technician_count) và diện tích xưởng (workshop_area_m2) rất quan trọng để phát hiện bẫy cam kết ảo.
"""


def parse_unstructured_text(raw_text: str) -> Dict[str, Any]:
    """
    Parses raw unstructured text from file or free text input.
    First tries Gemini API; falls back to heuristic extractor if unavailable.
    """
    if not raw_text or not raw_text.strip():
        return get_empty_schema()

    # Try Gemini LLM
    gemini_res = call_gemini(
        prompt=f"Hãy bóc tách hồ sơ đăng ký đại lý sau thành JSON chuẩn:\n\n{raw_text}",
        system_instruction=EXTRACTION_SYSTEM_PROMPT,
        json_mode=True
    )

    if gemini_res.get("success") and gemini_res.get("data"):
        data = gemini_res["data"]
        data["extraction_method"] = "GEMINI_AI"
        data["raw_source_text"] = raw_text[:2000]
        return normalize_intake_data(data)

    # Heuristic Fallback
    heuristic_data = extract_heuristics(raw_text)
    heuristic_data["extraction_method"] = "HEURISTIC_PARSER"
    heuristic_data["raw_source_text"] = raw_text[:2000]
    return normalize_intake_data(heuristic_data)


def extract_heuristics(text: str) -> Dict[str, Any]:
    """Advanced regular expression & heuristic parser for Vietnamese partner profiles."""
    res = get_empty_schema()

    # Tax ID (MST): 10 or 13 digits
    mst_match = re.search(r'(?:mã số thuế|mst|tax\s*id)[\s:]*([0-9]{10}(?:-[0-9]{3})?)', text, re.IGNORECASE)
    if not mst_match:
        mst_match = re.search(r'\b([0-9]{10})\b', text)
    if mst_match:
        res["legal_entity"]["tax_id"] = mst_match.group(1).strip()

    # Phone: Vietnamese mobile / landline
    phone_match = re.search(r'(?:sđt|điện thoại|tel|hotline|phone)[\s:]*([0-9\.\s]{10,12})', text, re.IGNORECASE)
    if not phone_match:
        phone_match = re.search(r'\b(0[35789][0-9]{8})\b', text)
    if phone_match:
        res["legal_entity"]["phone"] = re.sub(r'[\.\s]', '', phone_match.group(1).strip())

    # Email
    email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)
    if email_match:
        res["legal_entity"]["email"] = email_match.group(0).strip()

    # Company Name: prioritize labeled line, exclude Đại Thành itself
    named_match = re.search(r'(?:tên công ty|ten cong ty|tên đơn vị|ten don vi|tên pháp nhân|ten phap nhan|tên đại lý|ten dai ly|tên doanh nghiệp|ten doanh nghiep)[\s:]+([^\n\r]+)', text, re.IGNORECASE)
    if named_match:
        cname = named_match.group(1).strip(' :,.')
        if len(cname) > 3 and "Đại Thành" not in cname:
            res["legal_entity"]["company_name"] = cname[:80]

    if not res["legal_entity"]["company_name"]:
        for line in text.split('\n'):
            line_str = line.strip()
            if "Đại Thành" in line_str or "DAI THANH" in line_str.upper():
                continue
            if re.search(r'(?:công ty|cong ty|cty|doanh nghiệp|nhà phân phối|tổng kho|đại lý|cửa hàng)', line_str, re.IGNORECASE):
                comp_cand = re.search(r'((?:công ty|cong ty|cty|doanh nghiệp|nhà phân phối|tổng kho|đại lý|cửa hàng)[\s\w\.\,\&\-]+)', line_str, re.IGNORECASE)
                if comp_cand:
                    cand_name = comp_cand.group(1).strip(' :,.')
                    if len(cand_name) > 6 and "Đại Thành" not in cand_name:
                        res["legal_entity"]["company_name"] = cand_name[:80]
                        break

    # Legal Representative: check specific terms first
    rep_matches = re.findall(r'(?:người đại diện pháp luật|nguoi dai dien phap luat|đại diện pháp luật|dai dien phap luat|người đại diện|nguoi dai dien|giám đốc|giam doc|chủ đại lý|chu dai ly)[\s:]+([^\n\r\|]+)', text, re.IGNORECASE)
    for cand in rep_matches:
        cand_rep = cand.split('-')[0].strip(' :,.')
        if len(cand_rep) >= 3 and not cand_rep.upper().startswith(("NGUOI", "TEN", "THONG", "1.", "2.", "3.")):
            res["legal_entity"]["legal_rep"] = cand_rep[:40]
            break

    # GPS coordinates: supports "Lat 16.0685, Long 108.1895" or "21.0312, 105.7950"
    gps_match = re.search(r'(?:tọa độ|toa do|gps|vĩ độ|kinh độ)?[\s:]*(?:lat)?[\s:]*([0-9]{2}\.[0-9]+)[,\s/|]+(?:long)?[\s:]*([0-9]{2,3}\.[0-9]+)', text, re.IGNORECASE)
    if gps_match:
        try:
            res["location_logistics"]["latitude"] = float(gps_match.group(1))
            res["location_logistics"]["longitude"] = float(gps_match.group(2))
        except Exception:
            pass

    # Address, District, Province
    addr_match = re.search(r'(?:địa chỉ|dia chi|trụ sở|tru so|điểm bán|diem ban|showroom|cửa hàng)[\s:]+([^\n\r]+)', text, re.IGNORECASE)
    if addr_match:
        addr = addr_match.group(1).strip()
        res["location_logistics"]["address"] = addr
        # Try infer province & district
        addr_lower = addr.lower()
        if "hà nội" in addr_lower or "ha noi" in addr_lower:
            res["location_logistics"]["province"] = "Hà Nội"
            res["legal_entity"]["region"] = "KV1"
        elif "đà nẵng" in addr_lower or "da nang" in addr_lower:
            res["location_logistics"]["province"] = "Đà Nẵng"
            res["legal_entity"]["region"] = "KV2"
        elif "hồ chí minh" in addr_lower or "tp.hcm" in addr_lower or "tp hcm" in addr_lower or "saigon" in addr_lower:
            res["location_logistics"]["province"] = "TP. Hồ Chí Minh"
            res["legal_entity"]["region"] = "KV3"
        elif "bình dương" in addr_lower or "binh duong" in addr_lower:
            res["location_logistics"]["province"] = "Bình Dương"
            res["legal_entity"]["region"] = "KV3"
        elif "nghệ an" in addr_lower or "nghe an" in addr_lower:
            res["location_logistics"]["province"] = "Nghệ An"
            res["legal_entity"]["region"] = "KV2"

        dist_match = re.search(r'(?:quận|huyện|thành phố|thị xã|quan|huyen)\s+([A-Za-z0-9\sĐđÀ-ỹ]+?)(?:,|$)', addr, re.IGNORECASE)
        if dist_match:
            res["location_logistics"]["district"] = dist_match.group(0).strip(' ,')

    # Revenue Commitment (e.g. 1.4 tỷ, 1,400,000,000 VND)
    # Check for raw number with separators first e.g. 1,400,000,000 or 1.400.000.000
    rev_raw = re.search(r'(?:doanh số|doanh thu|cam kết|doanh so)[\s\w:]*?([0-9]{1,3}(?:[,\.][0-9]{3}){2,3})\s*(?:vnd|đồng|đ)?', text, re.IGNORECASE)
    if rev_raw:
        cleaned_num = re.sub(r'[,\.]', '', rev_raw.group(1))
        res["commercial_commitment"]["committed_monthly_revenue"] = int(cleaned_num)
    else:
        rev_match = re.search(r'(?:doanh số|doanh thu|cam kết|doanh so)[\s\w:]*?([0-9]+(?:[\.,][0-9]+)?)\s*(tỷ|tỉ|ty|triệu|trieu|tr)?', text, re.IGNORECASE)
        if rev_match:
            num = float(rev_match.group(1).replace(',', '.'))
            unit = (rev_match.group(2) or "").lower()
            if "tỷ" in unit or "tỉ" in unit or "ty" in unit or num < 50:
                res["commercial_commitment"]["committed_monthly_revenue"] = int(num * 1_000_000_000)
            elif "triệu" in unit or "trieu" in unit or "tr" in unit:
                res["commercial_commitment"]["committed_monthly_revenue"] = int(num * 1_000_000)

    # Debt Days (Công nợ: 30 ngày, 45 ngày, 60 ngày)
    debt_match = re.search(r'(?:thời hạn nợ|công nợ|nợ gối đầu|hạn mức nợ|thoi han no|cong no)[\s\w:]*?([0-9]{1,3})\s*(?:ngày|ngay|day)', text, re.IGNORECASE)
    if debt_match:
        res["financial_credit"]["requested_debt_days"] = int(debt_match.group(1))

    # Requested Credit Limit (Hạn mức công nợ)
    cred_raw = re.search(r'(?:hạn mức|tín chấp|đề xuất nợ|han muc)[\s\w:]*?([0-9]{1,3}(?:[,\.][0-9]{3}){2,3})\s*(?:vnd|đồng|đ)?', text, re.IGNORECASE)
    if cred_raw:
        cleaned_cred = re.sub(r'[,\.]', '', cred_raw.group(1))
        res["financial_credit"]["requested_credit_limit"] = int(cleaned_cred)
    else:
        cred_match = re.search(r'(?:hạn mức|tín chấp|đề xuất nợ|han muc)[\s\w:]*?([0-9]+(?:[\.,][0-9]+)?)\s*(tỷ|tỉ|ty|triệu|trieu|tr)', text, re.IGNORECASE)
        if cred_match:
            num = float(cred_match.group(1).replace(',', '.'))
            unit = cred_match.group(2).lower()
            if "tỷ" in unit or "tỉ" in unit or "ty" in unit:
                res["financial_credit"]["requested_credit_limit"] = int(num * 1_000_000_000)
            else:
                res["financial_credit"]["requested_credit_limit"] = int(num * 1_000_000)

    # Bank guarantee
    if re.search(r'(?:bảo lãnh ngân hàng|thư bảo lãnh|có bảo lãnh|bao lanh ngan hang|thu bao lanh|co bao lanh)', text, re.IGNORECASE):
        if not re.search(r'(?:không có|chưa có|khong co|chua co)\s+bảo lãnh', text, re.IGNORECASE):
            res["financial_credit"]["has_bank_guarantee"] = True

    # Technician count (Số thợ KTV)
    tech_match = re.search(r'([0-9]+)\s*(?:thợ|kỹ thuật viên|ktv|nhân viên kỹ thuật|tho|ky thuat vien)', text, re.IGNORECASE)
    if tech_match:
        res["technical_service"]["technician_count"] = int(tech_match.group(1))
    elif re.search(r'(?:không có thợ|chưa có kỹ thuật|0 thợ|không có ktv|khong co tho|0 tho)', text, re.IGNORECASE):
        res["technical_service"]["technician_count"] = 0

    # Workshop Area (Diện tích xưởng/trạm)
    area_match = re.search(r'(?:xưởng|trạm bảo hành|khu bảo hành|diện tích sửa chữa|xuong|tram bao hanh)[\s\w:]*?([0-9]+(?:[\.,][0-9]+)?)\s*(?:m2|m²)', text, re.IGNORECASE)
    if area_match:
        res["technical_service"]["workshop_area_m2"] = float(area_match.group(1).replace(',', '.'))

    # SLA commitment
    sla_match = re.search(r'(?:sla|thời gian xử lý|bảo hành trong|phản hồi trong|thoi gian xu ly)[\s\w:]*?([0-9]+)\s*(?:giờ|h|tiếng|gio)', text, re.IGNORECASE)
    if sla_match:
        res["technical_service"]["sla_commit_hours"] = int(sla_match.group(1))

    # Warehouse area
    wh_match = re.search(r'(?:kho|kho bãi|diện tích kho|dien tich kho)[\s\w:]*?([0-9]+(?:[\.,][0-9]+)?)\s*(?:m2|m²)', text, re.IGNORECASE)
    if wh_match:
        res["location_logistics"]["warehouse_area_m2"] = float(wh_match.group(1).replace(',', '.'))

    # Front width
    front_match = re.search(r'(?:mặt tiền|bề ngang|mat tien)[\s\w:]*?([0-9]+(?:[\.,][0-9]+)?)\s*m', text, re.IGNORECASE)
    if front_match:
        res["location_logistics"]["store_front_width_m"] = float(front_match.group(1).replace(',', '.'))

    return res


def get_empty_schema() -> Dict[str, Any]:
    """Returns an empty standardized schema template."""
    return {
        "legal_entity": {
            "company_name": "",
            "tax_id": "",
            "legal_rep": "",
            "phone": "",
            "email": "",
            "established_year": 2022,
            "region": "KV1"
        },
        "location_logistics": {
            "address": "",
            "district": "",
            "province": "",
            "latitude": 21.0285,
            "longitude": 105.8542,
            "store_front_width_m": 8.0,
            "warehouse_area_m2": 100.0,
            "truck_accessible": True
        },
        "commercial_commitment": {
            "committed_monthly_revenue": 1000000000,
            "product_lines": ["Bếp từ", "Máy lọc nước", "Bình nước nóng"],
            "target_channels": ["Đại lý cấp 2", "Bán lẻ"],
            "industry_experience_years": 3
        },
        "technical_service": {
            "technician_count": 2,
            "workshop_area_m2": 20.0,
            "sla_commit_hours": 48,
            "spare_parts_stock": True
        },
        "financial_credit": {
            "requested_credit_limit": 300000000,
            "requested_debt_days": 30,
            "has_bank_guarantee": False,
            "charter_capital": 2000000000
        }
    }


def normalize_intake_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """Ensures all expected fields exist and types are properly normalized."""
    template = get_empty_schema()

    normalized = {}
    for section_key, section_val in template.items():
        user_section = data.get(section_key, {})
        if not isinstance(user_section, dict):
            user_section = {}

        normalized[section_key] = {}
        for field_key, default_val in section_val.items():
            val = user_section.get(field_key, default_val)
            # Type casting
            if isinstance(default_val, bool):
                if isinstance(val, str):
                    val = val.lower() in ["true", "1", "yes", "có"]
                else:
                    val = bool(val)
            elif isinstance(default_val, int) and not isinstance(default_val, bool):
                try:
                    val = int(float(val))
                except (ValueError, TypeError):
                    val = default_val
            elif isinstance(default_val, float):
                try:
                    val = float(val)
                except (ValueError, TypeError):
                    val = default_val
            elif isinstance(default_val, list):
                if isinstance(val, str):
                    val = [item.strip() for item in val.split(",") if item.strip()]
                elif not isinstance(val, list):
                    val = default_val
            else:
                val = str(val).strip() if val is not None else ""

            normalized[section_key][field_key] = val

    # Preserve metadata fields
    if "extraction_method" in data:
        normalized["extraction_method"] = data["extraction_method"]
    if "raw_source_text" in data:
        normalized["raw_source_text"] = data["raw_source_text"]

    return normalized
