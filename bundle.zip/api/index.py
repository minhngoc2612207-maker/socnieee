import os
import sys

# Ensure root directory is in sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Set serverless environment marker
os.environ["VERCEL"] = "1"

# Import Flask WSGI app from server.py
from server import app

# Vercel entrypoint looks for 'app'
if __name__ == "__main__":
    app.run()
